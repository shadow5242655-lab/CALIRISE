# **App Name**: CaliRise

## Core Features:

- Progressive Exercise Library: A curated directory of calisthenics movements categorized from absolute beginner (wall push-ups) to elite level (one-arm handstand).
- Dynamic Session Timer: Integrated workout player that cycles through exercises with configurable high-intensity intervals and programmed rest periods.
- AI Personal Path Tool: A generative AI tool that evaluates your current reps and skill goals to create a customized progression routine and recovery plan.
- Ascension Leveling System: Gamified progression tracking where users earn experience points (XP) per workout to level up from 'Novice' to 'Grandmaster'.
- The Pavilion Community: A real-time global feed where athletes can share session results, milestone achievements, and discuss training techniques.
- Body Composition Tracker: Visual logging of body transformations and weight to help correlate muscle gain with calisthenics volume.
- Technique AI Feedback: Tool that analyzes video uploads to offer suggestions on posture and leverage for advanced isometric holds.

## Style Guidelines:

- Primary color: Electric Cobalt (#3B82F6) symbolizing high performance and focus.
- Background color: Deep Onyx (#0F1115), a heavily desaturated dark navy that reduces eye strain and looks sleek in high-end fitness settings.
- Accent color: Neon Orchid (#B49EFF), an analogous purple-blue shift used for level-up badges and active timers to provide sharp contrast.
- Headline font: 'Space Grotesk' for a technical, scientific fitness vibe; Body font: 'Inter' for maximum readability during intense workouts.
- Monolinear, geometric icons with a bold stroke to ensure visibility when the user's phone is placed at a distance during training.
- Minimalist grid-based structure focused on maximizing vertical screen space for workout sequences and status dashboards.
- Spring-physics transitions for 'Level Up' notifications to make progress feel tactile and rewarding.