'use server';
/**
 * @fileOverview A Genkit flow for generating personalized calisthenics workout routines and recovery plans.
 *
 * - generatePersonalizedWorkoutPlan - A function that handles the generation of the workout and recovery plan.
 * - PersonalizedWorkoutPlanInput - The input type for the generatePersonalizedWorkoutPlan function.
 * - PersonalizedWorkoutPlanOutput - The return type for the generatePersonalizedWorkoutPlan function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExerciseSchema = z.object({
  name: z.string().describe('The name of the exercise.'),
  sets: z.number().int().min(1).describe('The number of sets for the exercise.'),
  reps: z
    .union([z.number().int().min(1), z.literal('AMRAP'), z.literal('To Failure')])
    .describe('The number of repetitions per set, or "AMRAP", or "To Failure".'),
  notes: z.string().optional().describe('Any additional notes or instructions for the exercise.'),
});

const WorkoutDaySchema = z.object({
  day: z.string().describe('The name of the workout day (e.g., "Day 1: Upper Body", "Rest Day").'),
  exercises: z.array(ExerciseSchema).optional().describe('A list of exercises for this workout day. Omitted for rest days.'),
  focus: z.string().optional().describe('The primary focus for this workout day.'),
});

const PersonalizedWorkoutPlanInputSchema = z.object({
  currentReps: z
    .record(z.string(), z.number().int().min(0))
    .describe('A map of exercise names to the current number of reps the user can perform for that exercise.'),
  skillGoals: z
    .array(z.string())
    .describe('A list of skill goals the user wants to achieve (e.g., "achieve a handstand").'),
});
export type PersonalizedWorkoutPlanInput = z.infer<typeof PersonalizedWorkoutPlanInputSchema>;

const PersonalizedWorkoutPlanOutputSchema = z.object({
  recommendedLevelId: z.number().int().min(1).max(4).describe('The recommended mastery level ID: 1 for Beginner, 2 for Intermediate, 3 for Advanced, 4 for Elite.'),
  workoutRoutine: z
    .array(WorkoutDaySchema)
    .describe('A progressive workout routine tailored to the user, structured by days or phases.'),
  recoveryPlan: z
    .string()
    .describe('A recommended recovery plan, including rest days, active recovery, and stretching.'),
  notes: z.string().describe('Any general notes or advice for the user.'),
});
export type PersonalizedWorkoutPlanOutput = z.infer<typeof PersonalizedWorkoutPlanOutputSchema>;

export async function generatePersonalizedWorkoutPlan(
  input: PersonalizedWorkoutPlanInput
): Promise<PersonalizedWorkoutPlanOutput> {
  return generatePersonalizedWorkoutPlanFlow(input);
}

const prompt = ai.definePrompt({
  name: 'personalizedWorkoutPlanPrompt',
  input: {schema: PersonalizedWorkoutPlanInputSchema},
  output: {schema: PersonalizedWorkoutPlanOutputSchema},
  prompt: `You are an expert calisthenics coach. Analyze the athlete's baseline and goals.

Athlete Stats:
{{#each currentReps}}
- {{ @key }}: {{ this }} reps
{{/each}}

Aspirations:
{{#each skillGoals}}
- {{{this}}}
{{/each}}

Phase 1: Determine Recommended Level ID (1-4).
- 1: Beginner (< 5 pullups)
- 2: Intermediate (5-12 pullups)
- 3: Advanced (> 12 pullups)
- 4: Elite (Planche/Front Lever work)

Phase 2: Generate a 7-day routine tailored to their goals.
Phase 3: Provide a recovery plan.

Adhere strictly to the JSON schema. Use integers for numbers where specified.`,
});

const generatePersonalizedWorkoutPlanFlow = ai.defineFlow(
  {
    name: 'generatePersonalizedWorkoutPlanFlow',
    inputSchema: PersonalizedWorkoutPlanInputSchema,
    outputSchema: PersonalizedWorkoutPlanOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    if (!output) {
      throw new Error('AI failed to generate a plan. Please try again.');
    }
    return output;
  }
);
