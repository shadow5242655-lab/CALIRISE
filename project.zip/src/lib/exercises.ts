
/**
 * @fileOverview Overhauled exercise database using wger API IDs.
 * Expanded with high-quality foundational movements to serve as a library fallback.
 */

export type Exercise = {
  id: number; // wger ID or internal ID
  name: string;
  level: "Beginner" | "Intermediate" | "Advanced" | "Elite";
  category: "Push" | "Pull" | "Legs" | "Core" | "Skills";
  xp: number;
  img: string;
  wgerId: number;
  defaultUnit: "reps" | "seconds";
  defaultTarget: number;
  description: string;
};

export const EXERCISES: Exercise[] = [
  { 
    id: 192, 
    name: "Standard Pushups", 
    level: "Intermediate", 
    category: "Push", 
    xp: 30, 
    img: "push-up", 
    wgerId: 192, 
    defaultUnit: "reps", 
    defaultTarget: 15,
    description: "The foundation of all pushing strength. Maintain a straight line from head to heels."
  },
  { 
    id: 191, 
    name: "Strict Pull-ups", 
    level: "Advanced", 
    category: "Pull", 
    xp: 100, 
    img: "pull-up", 
    wgerId: 191, 
    defaultUnit: "reps", 
    defaultTarget: 8,
    description: "Vertical pulling mastery. Pull until your chin passes the bar with no kipping."
  },
  { 
    id: 190, 
    name: "Parallel Bar Dips", 
    level: "Advanced", 
    category: "Push", 
    xp: 80, 
    img: "push-up", 
    wgerId: 190, 
    defaultUnit: "reps", 
    defaultTarget: 10,
    description: "Build massive triceps and lower chest power. Lower until shoulders are below elbows."
  },
  { 
    id: 177, 
    name: "Bodyweight Squats", 
    level: "Beginner", 
    category: "Legs", 
    xp: 15, 
    img: "push-up", 
    wgerId: 177, 
    defaultUnit: "reps", 
    defaultTarget: 20,
    description: "Develop lower body mobility and strength. Keep your chest up and weight on your heels."
  },
  { 
    id: 174, 
    name: "Hardcore Plank", 
    level: "Beginner", 
    category: "Core", 
    xp: 20, 
    img: "handstand", 
    wgerId: 174, 
    defaultUnit: "seconds", 
    defaultTarget: 45,
    description: "Core stability essential. Squeeze your glutes and core to maintain a hollow body."
  },
  { 
    id: 168, 
    name: "Hanging Leg Raises", 
    level: "Advanced", 
    category: "Core", 
    xp: 50, 
    img: "handstand", 
    wgerId: 168, 
    defaultUnit: "reps", 
    defaultTarget: 12,
    description: "Elite core compression. Raise your legs to the bar without using momentum."
  },
  { 
    id: 13, 
    name: "Pike Pushups", 
    level: "Intermediate", 
    category: "Push", 
    xp: 40, 
    img: "handstand", 
    wgerId: 13, 
    defaultUnit: "reps", 
    defaultTarget: 10,
    description: "The gateway to the handstand push-up. Focus on vertical pushing mechanics."
  },
  { 
    id: 818, 
    name: "Handstand Hold", 
    level: "Advanced", 
    category: "Skills", 
    xp: 200, 
    img: "handstand", 
    wgerId: 818, 
    defaultUnit: "seconds", 
    defaultTarget: 15,
    description: "The ultimate display of balance and shoulder stability."
  },
];
