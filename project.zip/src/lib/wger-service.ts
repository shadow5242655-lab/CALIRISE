
/**
 * @fileOverview Service for interacting with the wger public API.
 * https://wger.de/api/v2/
 */

export const WGER_API_BASE = 'https://wger.de/api/v2';
export const LANGUAGE_ID = 2; // English

export type WgerExercise = {
  id: number;
  name: string;
  description: string;
  category: number;
  muscles?: number[];
  equipment?: number[];
  image?: string;
};

export async function getWgerExercisesByCategory(categoryId: number): Promise<WgerExercise[]> {
  try {
    const response = await fetch(`${WGER_API_BASE}/exercise/?category=${categoryId}&language=${LANGUAGE_ID}&limit=100&format=json`);
    if (!response.ok) return [];
    const data = await response.json();
    
    return (data.results || [])
      .filter((ex: any) => ex.name && ex.name.trim() !== "" && !ex.name.toLowerCase().includes("unknown"))
      .map((ex: any) => ({
        id: ex.id,
        name: ex.name,
        description: ex.description || "Foundational movement for bodyweight mastery.",
        category: ex.category,
        muscles: ex.muscles || [],
        equipment: ex.equipment || []
      }));
  } catch (e) {
    console.error("wger category fetch error:", e);
    return [];
  }
}

export async function getWgerExerciseInfo(exerciseId: number): Promise<WgerExercise | null> {
  if (!exerciseId || exerciseId === 0) return null;
  try {
    const response = await fetch(`${WGER_API_BASE}/exerciseinfo/${exerciseId}/?format=json`);
    if (!response.ok) return null;
    const data = await response.json();
    return {
      id: data.id,
      name: data.name || "Unknown Technique",
      description: data.description || "Mastery technique focused on functional bodyweight control.",
      category: data.category?.id || 0,
      muscles: data.muscles?.map((m: any) => m.id) || [],
      equipment: data.equipment?.map((e: any) => e.id) || []
    };
  } catch (e) {
    console.error("wger info fetch error:", e);
    return null;
  }
}

export const CATEGORY_MAP = {
  ARMS: 8,
  LEGS: 9,
  ABS: 10,
  CHEST: 11,
  BACK: 12,
  SHOULDERS: 13,
};

export const CATEGORY_IDS = {
  8: "Arms",
  9: "Legs",
  10: "Abs",
  11: "Chest",
  12: "Back",
  13: "Shoulders"
};
