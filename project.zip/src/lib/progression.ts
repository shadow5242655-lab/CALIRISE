
/**
 * @fileOverview Progression logic using wger exercise IDs for accuracy.
 * Overhauled to provide 5-6 exercises per training day for optimal intensity.
 */

export const generate30DayPlan = (levelId: number) => {
  const patterns: Record<number, any[]> = {
    1: [ // Beginner: Foundation & Joint Integrity
      { 
        focus: "Push Foundations", 
        exercises: [
          { name: "Wall Push-ups", target: "15 reps", reps: 15, wgerId: 192, link: "https://www.youtube.com/results?search_query=wall+pushups+form" }, 
          { name: "Box Squats", target: "15 reps", reps: 15, wgerId: 177, link: "https://www.youtube.com/results?search_query=box+squats+form" },
          { name: "Knee Plank", target: "30s", seconds: 30, wgerId: 174, link: "https://www.youtube.com/results?search_query=knee+plank+form" },
          { name: "Bird Dog", target: "10 reps", reps: 10, wgerId: 174, link: "https://www.youtube.com/results?search_query=bird+dog+exercise" },
          { name: "Glute Bridges", target: "15 reps", reps: 15, wgerId: 177, link: "https://www.youtube.com/results?search_query=glute+bridge+form" }
        ] 
      },
      { 
        focus: "Pull Foundations", 
        exercises: [
          { name: "Doorway Rows", target: "15 reps", reps: 15, wgerId: 191, link: "https://www.youtube.com/results?search_query=doorway+rows+form" }, 
          { name: "Active Dead Hang", target: "30s", seconds: 30, wgerId: 191, link: "https://www.youtube.com/results?search_query=active+dead+hang+form" },
          { name: "Reverse Lunges", target: "10 reps", reps: 10, wgerId: 107, link: "https://www.youtube.com/results?search_query=reverse+lunges+form" },
          { name: "Superman Hold", target: "20s", seconds: 20, wgerId: 174, link: "https://www.youtube.com/results?search_query=superman+exercise+form" },
          { name: "Scapular Shrugs", target: "15 reps", reps: 15, wgerId: 191, link: "https://www.youtube.com/results?search_query=scapular+shrugs+form" }
        ] 
      },
      { 
        focus: "Core & Mobility", 
        exercises: [
          { name: "Knee Plank", target: "45s", seconds: 45, wgerId: 174, link: "https://www.youtube.com/results?search_query=knee+plank+form" }, 
          { name: "Lying Leg Raises", target: "10 reps", reps: 10, wgerId: 168, link: "https://www.youtube.com/results?search_query=lying+leg+raises+form" },
          { name: "Cat-Cow Stretch", target: "60s", seconds: 60, wgerId: 174, link: "https://www.youtube.com/results?search_query=cat+cow+stretch" },
          { name: "Side Plank (Knee)", target: "30s/side", seconds: 30, wgerId: 174, link: "https://www.youtube.com/results?search_query=side+plank+knee+form" },
          { name: "Cobra Stretch", target: "30s", seconds: 30, wgerId: 174, link: "https://www.youtube.com/results?search_query=cobra+stretch" }
        ] 
      },
      { focus: "Recovery", exercises: [] }
    ],
    2: [ // Intermediate: Volume & Basic Skills
      { 
        focus: "Push Volume", 
        exercises: [
          { name: "Standard Pushups", target: "20 reps", reps: 20, wgerId: 192, link: "https://www.youtube.com/results?search_query=pushup+form" }, 
          { name: "Parallel Bar Dips", target: "10 reps", reps: 10, wgerId: 190, link: "https://www.youtube.com/results?search_query=dips+form" },
          { name: "Pike Pushups", target: "8 reps", reps: 8, wgerId: 13, link: "https://www.youtube.com/results?search_query=pike+pushup+form" },
          { name: "Bench Dips", target: "15 reps", reps: 15, wgerId: 190, link: "https://www.youtube.com/results?search_query=bench+dips+form" },
          { name: "Mountain Climbers", target: "45s", seconds: 45, wgerId: 174, link: "https://www.youtube.com/results?search_query=mountain+climbers+form" },
          { name: "Plank to Pushup", target: "10 reps", reps: 10, wgerId: 192, link: "https://www.youtube.com/results?search_query=plank+to+pushup+form" }
        ] 
      },
      { 
        focus: "Pull Volume", 
        exercises: [
          { name: "Australian Rows", target: "12 reps", reps: 12, wgerId: 191, link: "https://www.youtube.com/results?search_query=australian+rows+form" }, 
          { name: "Negative Pullups", target: "8 reps", reps: 8, wgerId: 191, link: "https://www.youtube.com/results?search_query=negative+pullups+form" },
          { name: "Chin-ups", target: "5 reps", reps: 5, wgerId: 191, link: "https://www.youtube.com/results?search_query=chin+up+form" },
          { name: "Scapular Pullups", target: "12 reps", reps: 12, wgerId: 191, link: "https://www.youtube.com/results?search_query=scapular+pullups+form" },
          { name: "Jump Pullups", target: "10 reps", reps: 10, wgerId: 191, link: "https://www.youtube.com/results?search_query=jump+pullups+form" }
        ] 
      },
      { 
        focus: "Legs & Core", 
        exercises: [
          { name: "Bodyweight Squats", target: "25 reps", reps: 25, wgerId: 177, link: "https://www.youtube.com/results?search_query=bodyweight+squat+form" }, 
          { name: "Hanging Leg Raises", target: "12 reps", reps: 12, wgerId: 168, link: "https://www.youtube.com/results?search_query=hanging+leg+raises+form" },
          { name: "Russian Twists", target: "30 reps", reps: 30, wgerId: 10, link: "https://www.youtube.com/results?search_query=russian+twist+form" },
          { name: "Walking Lunges", target: "20 reps", reps: 20, wgerId: 107, link: "https://www.youtube.com/results?search_query=walking+lunges+form" },
          { name: "Hollow Body Hold", target: "30s", seconds: 30, wgerId: 174, link: "https://www.youtube.com/results?search_query=hollow+body+hold+form" },
          { name: "Calf Raises", target: "20 reps", reps: 20, wgerId: 9, link: "https://www.youtube.com/results?search_query=calf+raises+form" }
        ] 
      },
      { focus: "Rest", exercises: [] }
    ],
    3: [ // Advanced: Skill Push & Dynamic Pull
      { 
        focus: "Skill Push", 
        exercises: [
          { name: "Elevated Pike Pushups", target: "10 reps", reps: 10, wgerId: 13, link: "https://www.youtube.com/results?search_query=elevated+pike+pushup+form" }, 
          { name: "Diamond Pushups", target: "15 reps", reps: 15, wgerId: 192, link: "https://www.youtube.com/results?search_query=diamond+pushup+form" },
          { name: "pseudo Planche Pushups", target: "8 reps", reps: 8, wgerId: 192, link: "https://www.youtube.com/results?search_query=pseudo+planche+pushup+form" },
          { name: "Deep Chest Dips", target: "12 reps", reps: 12, wgerId: 190, link: "https://www.youtube.com/results?search_query=chest+dips+form" },
          { name: "Archer Pushups", target: "10 reps", reps: 10, wgerId: 192, link: "https://www.youtube.com/results?search_query=archer+pushup+form" }
        ] 
      },
      { 
        focus: "Skill Pull", 
        exercises: [
          { name: "Strict Pullups", target: "10 reps", reps: 10, wgerId: 191, link: "https://www.youtube.com/results?search_query=strict+pullup+form" }, 
          { name: "L-sit Pullups", target: "5 reps", reps: 5, wgerId: 191, link: "https://www.youtube.com/results?search_query=l+sit+pullup+form" },
          { name: "Wide Grip Pullups", target: "8 reps", reps: 8, wgerId: 191, link: "https://www.youtube.com/results?search_query=wide+grip+pullup+form" },
          { name: "Archer Rows", target: "10 reps", reps: 10, wgerId: 191, link: "https://www.youtube.com/results?search_query=archer+rows+form" },
          { name: "Explosive Pullups", target: "5 reps", reps: 5, wgerId: 191, link: "https://www.youtube.com/results?search_query=explosive+pullup+form" }
        ] 
      },
      { 
        focus: "Statics & Core", 
        exercises: [
          { name: "Wall Handstand", target: "45s", seconds: 45, wgerId: 818, link: "https://www.youtube.com/results?search_query=wall+handstand+form" }, 
          { name: "L-Sit (Parallel)", target: "20s", seconds: 20, wgerId: 174, link: "https://www.youtube.com/results?search_query=l+sit+form" },
          { name: "Crow Pose", target: "30s", seconds: 30, wgerId: 818, link: "https://www.youtube.com/results?search_query=crow+pose+form" },
          { name: "Tucked Planche", target: "10s", seconds: 10, wgerId: 818, link: "https://www.youtube.com/results?search_query=tucked+planche+form" },
          { name: "Dragon Flag Prep", target: "8 reps", reps: 8, wgerId: 174, link: "https://www.youtube.com/results?search_query=dragon+flag+progression" },
          { name: "Archery Squats", target: "10 reps", reps: 10, wgerId: 177, link: "https://www.youtube.com/results?search_query=archer+squats+form" }
        ] 
      },
      { focus: "Recovery", exercises: [] }
    ],
    4: [ // Elite: Static Mastery & Explosive Power
      { 
        focus: "Statics Mastery", 
        exercises: [
          { name: "Planche Leans", target: "30s", seconds: 30, wgerId: 818, link: "https://www.youtube.com/results?search_query=planche+leans+form" }, 
          { name: "Front Lever Pulls", target: "8 reps", reps: 8, wgerId: 191, link: "https://www.youtube.com/results?search_query=front+lever+pull+form" },
          { name: "Back Lever Hold", target: "15s", seconds: 15, wgerId: 191, link: "https://www.youtube.com/results?search_query=back+lever+form" },
          { name: "Straddle Planche Taps", target: "10 reps", reps: 10, wgerId: 818, link: "https://www.youtube.com/results?search_query=planche+taps+form" },
          { name: "Dragon Flag Hold", target: "20s", seconds: 20, wgerId: 174, link: "https://www.youtube.com/results?search_query=dragon+flag+form" }
        ] 
      },
      { 
        focus: "Elite Pull", 
        exercises: [
          { name: "Strict Muscle Ups", target: "5 reps", reps: 5, wgerId: 191, link: "https://www.youtube.com/results?search_query=strict+muscle+up+form" }, 
          { name: "OAP Negatives", target: "3 reps/side", reps: 3, wgerId: 191, link: "https://www.youtube.com/results?search_query=one+arm+pullup+negative" },
          { name: "Weighted Pullups", target: "8 reps", reps: 8, wgerId: 191, link: "https://www.youtube.com/results?search_query=weighted+pullup+form" },
          { name: "Archer Pullups", target: "10 reps", reps: 10, wgerId: 191, link: "https://www.youtube.com/results?search_query=archer+pullup+form" },
          { name: "Explosive Rows", target: "12 reps", reps: 12, wgerId: 191, link: "https://www.youtube.com/results?search_query=explosive+rows+form" }
        ] 
      },
      { 
        focus: "Elite Push", 
        exercises: [
          { name: "Freestanding HSPU", target: "5 reps", reps: 5, wgerId: 818, link: "https://www.youtube.com/results?search_query=handstand+pushup+form" }, 
          { name: "Weighted Dips", target: "10 reps", reps: 10, wgerId: 190, link: "https://www.youtube.com/results?search_query=weighted+dips+form" },
          { name: "Ring Muscle Ups", target: "5 reps", reps: 5, wgerId: 191, link: "https://www.youtube.com/results?search_query=ring+muscle+up+form" },
          { name: "One Arm Pushups", target: "8 reps/side", reps: 8, wgerId: 192, link: "https://www.youtube.com/results?search_query=one+arm+pushup+form" },
          { name: "Explosive Clap Pushups", target: "15 reps", reps: 15, wgerId: 192, link: "https://www.youtube.com/results?search_query=clap+pushup+form" }
        ] 
      },
      { focus: "Rest", exercises: [] }
    ]
  };

  const levelPattern = patterns[levelId] || patterns[1];
  const plan = [];
  for (let i = 1; i <= 30; i++) {
    plan.push({ day: `Day ${i}`, ...levelPattern[(i - 1) % 4] });
  }
  return plan;
};

export const LEVELS = [
  { id: 1, name: "Beginner", color: "text-emerald-400", plan: generate30DayPlan(1) },
  { id: 2, name: "Intermediate", color: "text-primary", plan: generate30DayPlan(2) },
  { id: 3, name: "Advanced", color: "text-amber-500", plan: generate30DayPlan(3) },
  { id: 4, name: "Elite", color: "text-rose-500", plan: generate30DayPlan(4) }
];

export const BADGES = [
  { id: 'first_workout', name: 'Iron Foundation' },
  { id: 'streak_7', name: 'Consistent Warrior' },
  { id: 'path_complete', name: 'Path Master' },
];

export const CHALLENGES = [
  { id: 'pushup_1000', name: 'Iron Chest 1000', description: '1,000 pushups total', target: 1000, unit: 'reps', reward: '500 XP' },
];
