
"use client";

import { AppShell } from "@/components/layout/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Utensils, Zap, Flame, Info, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUser, useDoc } from "@/firebase";
import { LEVELS } from "@/lib/progression";

const NUTRITION_TEMPLATES: Record<number, any[]> = {
  1: [ // Beginner: 120-140g Protein
    { breakfast: "4 Egg Whites + 1 Whole Egg + Oats", lunch: "150g Chicken + Brown Rice + Broccoli", snack: "Protein Shake + Banana", dinner: "150g White Fish + Sweet Potato" },
    { breakfast: "Greek Yogurt + Berries + Honey", lunch: "Tuna Salad (1 Can) + Whole Wheat Bread", snack: "Handful of Walnuts + Apple", dinner: "120g Lean Mince + Pasta" },
    { breakfast: "Protein Smoothie (Whey + Spinach + Oats)", lunch: "Grilled Turkey Wrap + Spinach", snack: "Cottage Cheese (Low-fat)", dinner: "150g Salmon + Asparagus" },
  ],
  2: [ // Intermediate: 140-160g Protein
    { breakfast: "6 Egg Whites + 2 Whole Eggs Scramble", lunch: "200g Grilled Chicken + Quinoa", snack: "Whey Protein + Handful of Almonds", dinner: "180g Lean Beef Mince + Sweet Potato" },
    { breakfast: "Oatmeal with Protein Powder & Blueberries", lunch: "200g Baked Salmon + Asparagus", snack: "Greek Yogurt (Non-fat) + Chia Seeds", dinner: "200g Grilled Turkey Breast + Brown Rice" },
    { breakfast: "Protein Pancakes (Oats, Eggs, Whey)", lunch: "200g Tuna Salad + Avocado", snack: "Cottage Cheese with Pineapple", dinner: "250g White Fish + Mixed Veggies" },
  ],
  3: [ // Advanced: 160-180g Protein
    { breakfast: "8 Egg Whites + 2 Whole Eggs + Avocado", lunch: "250g Chicken Breast + Quinoa + Greens", snack: "Double Scoop Whey + Cashews", dinner: "250g Lean Steak + Roasted Roots" },
    { breakfast: "Large Protein Oats (100g Oats + 2 Scoops)", lunch: "300g Cod + Large Salad + Olive Oil", snack: "Greek Yogurt + Hemp Seeds + Honey", dinner: "250g Turkey + Brown Rice + Zucchini" },
    { breakfast: "3 Whole Eggs + 2 Slices Whole Grain Toast", lunch: "250g Tuna + Chickpeas + Spinach", snack: "Beef Jerky (Low Sodium) + Almonds", dinner: "300g Salmon + Sweet Potato + Broccoli" },
  ],
  4: [ // Elite: 180-200g+ Protein
    { breakfast: "10 Egg Whites + 3 Whole Eggs + Spinach", lunch: "300g Chicken + Basmati Rice + Kale", snack: "2 Scoops Whey + Casein + Peanut Butter", dinner: "300g Lean Beef + Sweet Potato Mash" },
    { breakfast: "Protein Power Bowl (Oats, Whey, Eggs, Berries)", lunch: "350g White Fish + Large Quinoa Salad", snack: "Skyr Yogurt (High Protein) + Chia", dinner: "300g Grilled Salmon + Asparagus + Olive Oil" },
    { breakfast: "4 Whole Eggs + Avocado + Protein Shake", lunch: "300g Lean Turkey + Pasta + Tomato Sauce", snack: "Mixed Nuts + Whey + Creatine", dinner: "350g White Fish + Green Beans + Rice" },
  ]
};

function generateNutritionPlan(levelId: number) {
  const templates = NUTRITION_TEMPLATES[levelId] || NUTRITION_TEMPLATES[1];
  const proteinRange = levelId === 1 ? "120-140g" : levelId === 2 ? "140-160g" : levelId === 3 ? "160-180g" : "180g+";
  
  const plan = [];
  for (let i = 1; i <= 30; i++) {
    const mealType = templates[(i - 1) % 3];
    plan.push({
      day: `Day ${i}`,
      ...mealType,
      targetProtein: proteinRange,
      focus: i % 7 === 0 ? "Cheat/Refeed" : "Hypertrophy Fuel"
    });
  }
  return plan;
}

export default function NutritionPage() {
  const { user } = useUser();
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);
  const currentLevel = profile?.level || 1;
  const levelData = LEVELS.find(l => l.id === currentLevel);
  const plan = generateNutritionPlan(currentLevel);

  return (
    <AppShell>
      <div className="space-y-8 pb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-headline font-bold mb-2 uppercase tracking-tighter">Protein Pipeline</h1>
            <p className="text-muted-foreground text-lg">
              Fueling strategy optimized for the <span className={cn("font-black", levelData?.color)}>{levelData?.name.toUpperCase()}</span> path.
            </p>
          </div>
          <Badge className={cn("px-6 py-2 text-sm font-black uppercase tracking-widest", levelData?.color)}>
             {levelData?.name.toUpperCase()} RECOVERY
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-xl font-headline font-bold uppercase tracking-tight flex items-center gap-2 px-2">
              <Zap className="h-5 w-5 text-primary" />
              30-Day Fueling Cycle
            </h2>

            <div className="grid gap-4 max-h-[800px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-primary/20">
              {plan.map((day, idx) => (
                <Card key={idx} className="bg-card/50 border-border overflow-hidden hover:border-primary/30 transition-colors group">
                  <CardHeader className="bg-secondary/30 py-3 px-6 flex flex-row items-center justify-between border-b border-border">
                    <div>
                      <CardTitle className="text-sm font-headline uppercase tracking-widest">{day.day}</CardTitle>
                      <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">{day.focus}</p>
                    </div>
                    <Badge variant="outline" className="text-[10px] border-accent/50 text-accent font-black">
                      {day.targetProtein} PROTEIN
                    </Badge>
                  </CardHeader>
                  <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <p className="text-[10px] font-black uppercase text-primary/70">Breakfast</p>
                        <p className="text-xs font-bold">{day.breakfast}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black uppercase text-primary/70">Lunch</p>
                        <p className="text-xs font-bold">{day.lunch}</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <p className="text-[10px] font-black uppercase text-primary/70">Afternoon Snack</p>
                        <p className="text-xs font-bold">{day.snack}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black uppercase text-primary/70">Dinner</p>
                        <p className="text-xs font-bold">{day.dinner}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <Card className="bg-primary text-primary-foreground border-none shadow-2xl shadow-primary/20 overflow-hidden relative">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Trophy className="h-24 w-24" />
              </div>
              <CardHeader>
                <CardTitle className="font-headline text-lg uppercase font-black flex items-center gap-2">
                  <Info className="h-5 w-5" />
                  Path Logic
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-background/20 rounded-xl">
                  <p className="text-[10px] font-black uppercase mb-1 opacity-70 tracking-widest">Mastery Level {currentLevel}</p>
                  <p className="text-xs leading-relaxed">
                    {currentLevel === 1 ? "Foundational protein to support initial skeletal muscle adaptation." :
                     currentLevel === 2 ? "Moderate surplus to fuel strength gains and parallel bar volume." :
                     currentLevel === 3 ? "Hyper-recovery for skill-intensive sessions like muscle-ups." :
                     "Extreme macro-load for elite CNS recovery and static hold power."}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
