
"use client";

import { useMemo, useState, useEffect } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Heart, MessageSquare, Share2, Award, Zap, Flame, Camera, ChevronRight, Trophy, TrendingUp, Loader2 } from "lucide-react";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";
import { useUser, useFirestore, useCollection, useDoc } from "@/firebase";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { CHALLENGES } from "@/lib/progression";

const FEED_ITEMS = [
  {
    id: 1,
    user: { name: "Alex Rover", rank: "Master", avatar: "AR" },
    content: "Just hit my first 10-second front lever hold! The AI progression path actually works. Consistency is king. 👑",
    type: "Achievement",
    image: "planche",
    stats: { likes: 124, comments: 12 },
    xpGained: "+250 XP"
  },
  {
    id: 2,
    user: { name: "Sarah Kin", rank: "Warrior", avatar: "SK" },
    content: "Day 14 of the Ayush Calisthenics streak. Feeling lighter and more explosive on my pull-ups. Who's training today?",
    type: "Session",
    stats: { likes: 82, comments: 5 },
    badge: "14 Day Streak"
  }
];

export default function PavilionPage() {
  const { user } = useUser();
  const db = useFirestore();
  const groupImage = PlaceHolderImages.find(img => img.id === 'community-athlete');

  const [localStats, setLocalStats] = useState({
    xp: 0,
    workouts: 0,
    streak: 0,
    initialized: false
  });

  useEffect(() => {
    setLocalStats({
      xp: parseInt(localStorage.getItem('ayush_xp') || '0'),
      workouts: parseInt(localStorage.getItem('ayush_workouts_count') || '0'),
      streak: parseInt(localStorage.getItem('ayush_streak') || '0'),
      initialized: true
    });
  }, []);

  const leaderboardQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "users"), orderBy("xp", "desc"), limit(10));
  }, [db]);

  const { data: leaderboardUsers } = useCollection<any>(leaderboardQuery);
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);

  const stats = {
    xp: profile?.xp || localStats.xp,
    workouts: profile?.workouts || localStats.workouts,
    streak: profile?.streak || localStats.streak
  };

  if (!localStats.initialized) {
    return (
      <AppShell>
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="h-8 w-8 text-primary animate-spin" />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="space-y-8 pb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-4xl font-headline font-bold uppercase tracking-tighter">The Pavilion</h1>
            <p className="text-muted-foreground">Global calisthenics command center. Rank up and dominate.</p>
          </div>
          <Button className="rounded-xl gap-2 font-bold h-12 px-6 shadow-xl shadow-primary/20">
            <Camera className="h-5 w-5" />
            Share Progress
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {CHALLENGES.map((challenge) => {
                 let progress = 0;
                 if (challenge.unit === 'reps') progress = Math.min(100, (stats.workouts * 15 / challenge.target) * 100);
                 if (challenge.unit === 'days') progress = Math.min(100, (stats.streak / challenge.target) * 100);
                 if (challenge.unit === 'workouts') progress = Math.min(100, (stats.workouts / challenge.target) * 100);

                 return (
                   <Card key={challenge.id} className="bg-card/50 border-border overflow-hidden group hover:border-primary/50 transition-all">
                      <CardHeader className="pb-2">
                         <div className="flex items-center justify-between">
                            <CardTitle className="text-sm font-headline uppercase font-black tracking-tight">{challenge.name}</CardTitle>
                            <Badge variant="outline" className="text-[8px] font-black uppercase text-accent border-accent/20">
                               {challenge.reward}
                            </Badge>
                         </div>
                         <CardDescription className="text-[10px] font-medium leading-tight">
                            {challenge.description}
                         </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-2">
                         <div className="flex justify-between text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                            <span>Progress</span>
                            <span>{Math.round(progress)}%</span>
                         </div>
                         <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                            <div className="h-full bg-primary transition-all duration-1000" style={{ width: `${progress}%` }} />
                         </div>
                      </CardContent>
                   </Card>
                 );
               })}
            </div>

            <Card className="bg-card/50 border-border overflow-hidden">
              <CardContent className="p-4 flex gap-4">
                 <Avatar className="h-10 w-10 border border-border">
                    <AvatarFallback className="bg-primary/20 text-primary">ME</AvatarFallback>
                 </Avatar>
                 <Input className="bg-secondary/50 border-border h-10 rounded-xl" placeholder="Share your session results..." />
              </CardContent>
            </Card>

            {FEED_ITEMS.map((item) => {
              const postImage = item.image ? PlaceHolderImages.find(img => img.id === item.image) : null;
              
              return (
                <Card key={item.id} className="bg-card/50 border-border">
                  <CardHeader className="flex flex-row items-center gap-4 pb-4">
                    <Avatar className="border border-border">
                      <AvatarFallback className="bg-accent/20 text-accent">{item.user.avatar}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold">{item.user.name}</span>
                        <Badge variant="secondary" className="text-[10px] font-bold uppercase tracking-widest">{item.user.rank}</Badge>
                      </div>
                      <span className="text-xs text-muted-foreground">2 hours ago</span>
                    </div>
                    {item.xpGained && (
                      <div className="px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-xs font-bold">
                        {item.xpGained}
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm leading-relaxed">{item.content}</p>
                    {item.image && postImage?.imageUrl && (
                      <div className="relative h-64 rounded-2xl overflow-hidden border border-border">
                        <Image 
                          src={postImage.imageUrl} 
                          alt="Community post" 
                          fill 
                          className="object-cover"
                          data-ai-hint={postImage.imageHint}
                        />
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="pt-0 flex items-center gap-6">
                    <button className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-red-500 transition-colors">
                      <Heart className="h-4 w-4" />
                      {item.stats.likes}
                    </button>
                    <button className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-primary transition-colors">
                      <MessageSquare className="h-4 w-4" />
                      {item.stats.comments}
                    </button>
                    <button className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-foreground transition-colors ml-auto">
                      <Share2 className="h-4 w-4" />
                      Share
                    </button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>

          <div className="space-y-6">
            <Card className="bg-card/50 border-border overflow-hidden flex flex-col h-fit">
              <div className="relative h-40">
                {groupImage?.imageUrl && (
                  <Image 
                    src={groupImage.imageUrl} 
                    alt="Pavilion" 
                    fill 
                    className="object-cover opacity-20 grayscale"
                    data-ai-hint={groupImage.imageHint}
                  />
                )}
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                   <Trophy className="h-10 w-10 text-yellow-500 mb-2 drop-shadow-2xl" />
                   <h3 className="text-2xl font-headline font-bold uppercase tracking-tighter">Global Rankings</h3>
                   <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mt-1">Season 1 Active</p>
                </div>
              </div>
              <CardContent className="p-0 flex-1">
                 <div className="divide-y divide-border/50">
                   {leaderboardUsers ? leaderboardUsers.map((lbUser, idx) => (
                     <div key={lbUser.id || idx} className={cn(
                       "flex items-center justify-between p-4 transition-colors",
                       lbUser.id === user?.uid ? "bg-primary/10" : "hover:bg-secondary/30"
                     )}>
                        <div className="flex items-center gap-3">
                           <span className={cn(
                             "w-6 font-headline font-bold",
                             idx === 0 ? "text-yellow-500" : idx === 1 ? "text-slate-400" : idx === 2 ? "text-amber-600" : "text-muted-foreground"
                           )}>{idx + 1}</span>
                           <div className="flex flex-col">
                              <span className="font-bold text-sm truncate max-w-[120px]">{lbUser.displayName || "Athlete"}</span>
                              <span className="text-[8px] font-black uppercase text-muted-foreground">Lvl {lbUser.level || 0}</span>
                           </div>
                        </div>
                        <div className="text-right">
                           <span className="text-sm font-black text-primary">{(lbUser.xp || 0).toLocaleString()} XP</span>
                        </div>
                     </div>
                   )) : (
                     <div className="p-10 text-center space-y-4">
                        <Zap className="h-8 w-8 text-primary animate-pulse mx-auto" />
                        <p className="text-[10px] font-black uppercase text-muted-foreground">Calibrating Ranks...</p>
                     </div>
                   )}
                 </div>
              </CardContent>
              <CardFooter className="p-4 border-t border-border">
                 <div className="w-full space-y-4">
                    <div className="flex items-center justify-between px-1">
                       <span className="text-[10px] font-black uppercase text-muted-foreground">Your Standing</span>
                       <span className="text-[10px] font-black text-primary">{(stats.xp).toLocaleString()} XP</span>
                    </div>
                    <Button variant="outline" className="w-full text-[10px] font-black uppercase tracking-widest gap-2 h-10 border-border">
                       View Complete Board <ChevronRight className="h-3 w-3" />
                    </Button>
                 </div>
              </CardFooter>
            </Card>

            <Card className="bg-primary border-none text-primary-foreground shadow-2xl shadow-primary/20">
               <CardHeader className="pb-2">
                  <div className="flex items-center gap-2">
                     <TrendingUp className="h-4 w-4" />
                     <CardTitle className="text-xs font-headline uppercase font-black">Elite Stats</CardTitle>
                  </div>
               </CardHeader>
               <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                     <div className="bg-black/10 rounded-xl p-3 text-center">
                        <p className="text-[8px] font-black uppercase opacity-70">Top 1%</p>
                        <p className="text-lg font-black">42.5k</p>
                     </div>
                     <div className="bg-black/10 rounded-xl p-3 text-center">
                        <p className="text-[8px] font-black uppercase opacity-70">Global Rank</p>
                        <p className="text-lg font-black">#852</p>
                     </div>
                  </div>
                  <p className="text-[9px] font-medium leading-relaxed opacity-80 text-center italic">
                    "The rankings only reflect the work you've already done. The real battle is your next set."
                  </p>
               </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
