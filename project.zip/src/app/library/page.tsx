
"use client";

import { useState, useEffect, useMemo } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Search, 
  Youtube, 
  Info, 
  Loader2, 
  PlayCircle, 
  Dumbbell, 
  Sparkles,
  Zap,
  Target,
  Hammer
} from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getWgerExercisesByCategory, CATEGORY_MAP, type WgerExercise, CATEGORY_IDS } from "@/lib/wger-service";
import { EXERCISES } from "@/lib/exercises";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";
import Image from "next/image";

const CATEGORIES = [
  { label: "Chest", id: CATEGORY_MAP.CHEST },
  { label: "Back", id: CATEGORY_MAP.BACK },
  { label: "Legs", id: CATEGORY_MAP.LEGS },
  { label: "Abs", id: CATEGORY_MAP.ABS },
  { label: "Shoulders", id: CATEGORY_MAP.SHOULDERS },
  { label: "Arms", id: CATEGORY_MAP.ARMS },
];

export default function LibraryPage() {
  const [activeCategoryId, setActiveCategoryId] = useState(CATEGORY_MAP.CHEST);
  const [apiExercises, setApiExercises] = useState<WgerExercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedExercise, setSelectedExercise] = useState<any | null>(null);

  useEffect(() => {
    async function fetchExercises() {
      setLoading(true);
      try {
        const data = await getWgerExercisesByCategory(activeCategoryId);
        setApiExercises(data);
      } catch (error) {
        console.error("Failed to fetch exercises:", error);
        setApiExercises([]);
      } finally {
        setLoading(false);
      }
    }
    fetchExercises();
  }, [activeCategoryId]);

  const allExercises = useMemo(() => {
    const local = EXERCISES
      .filter(ex => {
        const catMap: Record<string, number> = {
          "Push": CATEGORY_MAP.CHEST,
          "Pull": CATEGORY_MAP.BACK,
          "Legs": CATEGORY_MAP.LEGS,
          "Core": CATEGORY_MAP.ABS,
          "Skills": CATEGORY_MAP.SHOULDERS
        };
        return catMap[ex.category] === activeCategoryId;
      })
      .map(ex => ({
        id: ex.id,
        name: ex.name,
        description: ex.description,
        category: activeCategoryId,
        isFeatured: true,
        muscles: [],
        equipment: []
      }));

    return [...local, ...apiExercises];
  }, [apiExercises, activeCategoryId]);

  const filteredExercises = useMemo(() => {
    return allExercises.filter(ex => {
      const name = ex.name || "";
      return name.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [allExercises, searchQuery]);

  const stripHtml = (html: string) => {
    if (!html) return "";
    return html.replace(/<[^>]*>?/gm, '');
  };

  const getCategoryImage = (catId: number) => {
    const map: Record<number, string> = {
      [CATEGORY_MAP.CHEST]: 'push-up',
      [CATEGORY_MAP.BACK]: 'pull-up',
      [CATEGORY_MAP.LEGS]: 'hero-calisthenics',
      [CATEGORY_MAP.ABS]: 'handstand',
      [CATEGORY_MAP.SHOULDERS]: 'planche',
      [CATEGORY_MAP.ARMS]: 'push-up',
    };
    const imgId = map[catId] || 'hero-calisthenics';
    return PlaceHolderImages.find(img => img.id === imgId);
  };

  return (
    <AppShell>
      <div className="space-y-8 pb-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-4xl font-headline font-bold uppercase tracking-tighter">AYURISE Library</h1>
            <p className="text-muted-foreground">Mastery database: Foundational movements & Global techniques.</p>
          </div>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              className="pl-10 bg-card/50 border-border rounded-xl h-11" 
              placeholder="Search all movements..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {CATEGORIES.map((cat) => (
            <Badge
              key={cat.id}
              variant={activeCategoryId === cat.id ? "default" : "secondary"}
              className={cn(
                "cursor-pointer px-5 py-2 text-xs font-black uppercase tracking-widest rounded-full transition-all shrink-0",
                activeCategoryId === cat.id ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" : "hover:bg-secondary/80"
              )}
              onClick={() => setActiveCategoryId(cat.id)}
            >
              {cat.label}
            </Badge>
          ))}
        </div>

        {loading && apiExercises.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <Loader2 className="h-10 w-10 text-primary animate-spin" />
            <p className="text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em]">Syncing Neural Arsenal...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredExercises.length > 0 ? (
              filteredExercises.map((ex, idx) => {
                const placeholder = getCategoryImage(ex.category);
                return (
                  <Card key={`${ex.id}-${idx}`} className="group overflow-hidden bg-card/50 border-border hover:border-primary/50 transition-all shadow-xl flex flex-col relative">
                    {"isFeatured" in ex && (
                      <div className="absolute top-4 right-4 z-30">
                        <Badge className="bg-accent text-accent-foreground text-[8px] font-black uppercase tracking-widest px-2 py-0.5 shadow-lg">
                          <Sparkles className="h-3 w-3 mr-1 fill-current" /> Mastery Path
                        </Badge>
                      </div>
                    )}
                    
                    <div className="relative h-44 bg-secondary/30 flex items-center justify-center overflow-hidden">
                      {placeholder && (
                        <Image
                          src={placeholder.imageUrl}
                          alt={ex.name || "Exercise"}
                          fill
                          className="object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent z-10" />
                      <PlayCircle className="absolute h-10 w-10 text-white opacity-0 group-hover:opacity-100 transition-opacity z-20" />
                      <div className="absolute top-4 left-4 z-20">
                        <Badge variant="outline" className="bg-black/40 text-white border-white/20 text-[8px] font-black">
                          {CATEGORY_IDS[ex.category as keyof typeof CATEGORY_IDS] || "Tech"}
                        </Badge>
                      </div>
                    </div>

                    <CardContent className="p-6 flex-1 flex flex-col z-20">
                      <div className="space-y-2 mb-6 flex-1">
                        <h3 className="font-headline font-bold text-lg tracking-tight uppercase leading-tight">{ex.name}</h3>
                        <div className="text-[10px] text-muted-foreground line-clamp-3 leading-relaxed">
                          {stripHtml(ex.description)}
                        </div>
                      </div>
                      
                      <div className="flex flex-col gap-2 mt-auto">
                        <Button 
                          className="w-full rounded-xl h-10 gap-3 font-black uppercase text-[10px] tracking-widest bg-primary hover:bg-primary/90 shadow-lg shadow-primary/10"
                          onClick={() => window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent((ex.name || "") + " calisthenics form guide")}`, '_blank')}
                        >
                          <Youtube className="h-4 w-4" /> Watch Form Guide
                        </Button>
                        <Button 
                          variant="outline" 
                          className="rounded-xl h-10 gap-2 font-bold text-[10px] uppercase border-border hover:bg-secondary/50"
                          onClick={() => setSelectedExercise(ex)}
                        >
                          <Info className="h-3.5 w-3.5" /> Biometrics Data
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="col-span-full py-24 text-center border-2 border-dashed border-border rounded-3xl bg-secondary/5">
                <Search className="h-12 w-12 text-muted-foreground opacity-20 mx-auto mb-4" />
                <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">No techniques found in this category.</p>
                <Button 
                  variant="link" 
                  className="mt-2 text-[10px] font-bold text-primary uppercase"
                  onClick={() => {
                    setSearchQuery("");
                    setActiveCategoryId(CATEGORY_MAP.CHEST);
                  }}
                >
                  Reset Command Center
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      <Dialog open={!!selectedExercise} onOpenChange={(open) => !open && setSelectedExercise(null)}>
        <DialogContent className="sm:max-w-md bg-card border-border shadow-2xl rounded-2xl p-0 overflow-hidden">
          <div className="relative h-40 bg-primary/20">
             {selectedExercise && (
               <>
                 <Image
                    src={getCategoryImage(selectedExercise.category)?.imageUrl || ""}
                    alt="Biometric focus"
                    fill
                    className="object-cover opacity-40 grayscale"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
                 <div className="absolute bottom-4 left-6">
                    <Badge className="bg-primary text-primary-foreground text-[10px] font-black uppercase tracking-widest mb-2">
                       {CATEGORY_IDS[selectedExercise.category as keyof typeof CATEGORY_IDS]} Biometrics
                    </Badge>
                    <h2 className="text-2xl font-headline font-black uppercase tracking-tighter">
                       {selectedExercise.name}
                    </h2>
                 </div>
               </>
             )}
          </div>

          <div className="p-6 space-y-6">
            <div className="grid grid-cols-2 gap-4">
               <div className="p-3 bg-secondary/50 rounded-xl border border-border space-y-1">
                  <div className="flex items-center gap-2 text-[9px] font-black uppercase text-muted-foreground">
                     <Target className="h-3 w-3 text-primary" /> Target Muscles
                  </div>
                  <p className="text-xs font-bold uppercase truncate">
                    {selectedExercise?.muscles?.length > 0 ? "Multiple Groups" : "Major Compound"}
                  </p>
               </div>
               <div className="p-3 bg-secondary/50 rounded-xl border border-border space-y-1">
                  <div className="flex items-center gap-2 text-[9px] font-black uppercase text-muted-foreground">
                     <Hammer className="h-3 w-3 text-accent" /> Equipment
                  </div>
                  <p className="text-xs font-bold uppercase truncate">
                    {selectedExercise?.equipment?.length > 0 ? "Req. Gear" : "Bodyweight Only"}
                  </p>
               </div>
            </div>

            <div className="space-y-2">
               <h4 className="text-[10px] font-black uppercase tracking-widest text-primary flex items-center gap-2">
                  <Zap className="h-3 w-3" /> Technical Breakdown
               </h4>
               <div className="text-xs text-muted-foreground leading-relaxed font-medium bg-secondary/20 p-4 rounded-xl border border-border/50 max-h-48 overflow-y-auto">
                  {stripHtml(selectedExercise?.description || "Technical analysis currently undergoing calibration...")}
               </div>
            </div>

            <Button 
              className="w-full h-12 rounded-xl text-[10px] font-black uppercase tracking-widest"
              onClick={() => setSelectedExercise(null)}
            >
              Close Dossier
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
