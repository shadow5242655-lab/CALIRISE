
"use client";

import { useState, useMemo } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Trash2, 
  Sparkles, 
  Play, 
  Save, 
  Search, 
  Dumbbell, 
  Loader2,
  ChevronRight,
  Zap,
  Hammer
} from "lucide-react";
import { useUser, useFirestore, useCollection } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, serverTimestamp, query, orderBy } from "firebase/firestore";
import { EXERCISES, type Exercise } from "@/lib/exercises";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import { generatePersonalizedWorkoutPlan } from "@/ai/flows/personalized-workout-plan-flow";
import { cn } from "@/lib/utils";

export default function ForgeRoutinePage() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const router = useRouter();
  
  const [name, setName] = useState("");
  const [selectedExercises, setSelectedExercises] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isForging, setIsForging] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Fetch saved routines
  const routinesQuery = useMemo(() => {
    if (!db || !user) return null;
    return query(collection(db, "users", user.uid, "customRoutines"), orderBy("createdAt", "desc"));
  }, [db, user]);

  const { data: savedRoutines, loading: routinesLoading } = useCollection<any>(routinesQuery);

  const filteredExercises = useMemo(() => {
    return EXERCISES.filter(ex => 
      ex.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ex.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  function addExerciseToRoutine(ex: Exercise) {
    setSelectedExercises([
      ...selectedExercises,
      {
        id: ex.id,
        name: ex.name,
        unit: ex.defaultUnit,
        reps: ex.defaultUnit === "reps" ? ex.defaultTarget : 0,
        seconds: ex.defaultUnit === "seconds" ? ex.defaultTarget : 0,
        target: ex.defaultUnit === "reps" ? `${ex.defaultTarget} Reps` : `${ex.defaultTarget} Seconds`
      }
    ]);
  }

  function removeExercise(index: number) {
    setSelectedExercises(selectedExercises.filter((_, i) => i !== index));
  }

  async function handleSaveRoutine() {
    if (!name.trim()) return toast({ title: "Name Required", description: "Give your routine a strong name." });
    if (selectedExercises.length === 0) return toast({ title: "No Exercises", description: "Add at least one exercise to your path." });

    setIsForging(true);
    
    const routineData = {
      name: name.trim(),
      exercises: selectedExercises,
      createdAt: serverTimestamp()
    };

    if (user && db) {
      try {
        await addDoc(collection(db, "users", user.uid, "customRoutines"), routineData);
        toast({ title: "Routine Forged!", description: `${name} has been added to your arsenal.` });
        setName("");
        setSelectedExercises([]);
      } catch (e) {
        toast({ variant: "destructive", title: "Forge Failed", description: "Could not sync with the cloud." });
      }
    } else {
      // Local storage fallback for Guest Mode
      const local = JSON.parse(localStorage.getItem('ayush_custom_routines') || '[]');
      localStorage.setItem('ayush_custom_routines', JSON.stringify([...local, { ...routineData, id: Date.now().toString() }]));
      toast({ title: "Routine Saved", description: "Saved locally in Guest Mode." });
      setName("");
      setSelectedExercises([]);
    }
    
    setIsForging(false);
  }

  async function handleAIGenerate() {
    setIsGenerating(true);
    try {
      const result = await generatePersonalizedWorkoutPlan({
        currentReps: { "Pullups": 5, "Pushups": 15 }, // Mock current stats
        skillGoals: ["Handstand Mastery", "Muscle Up Foundations"]
      });

      setName(`AI: ${result.recommendedLevelId === 1 ? 'Beginner' : 'Elite'} Path`);
      const mappedExercises = result.workoutRoutine[0].exercises?.map(ex => ({
        id: 0,
        name: ex.name,
        unit: typeof ex.reps === 'number' ? 'reps' : 'seconds',
        reps: typeof ex.reps === 'number' ? ex.reps : 0,
        seconds: typeof ex.reps === 'number' ? 0 : 30,
        target: `${ex.reps} ${typeof ex.reps === 'number' ? 'Reps' : ''}`
      })) || [];
      
      setSelectedExercises(mappedExercises);
      toast({ title: "AI Plan Generated", description: "Review and refine your new routine below." });
    } catch (e) {
      toast({ variant: "destructive", title: "AI Error", description: "The neural forge is busy. Try again." });
    }
    setIsGenerating(false);
  }

  async function handleDeleteRoutine(routineId: string) {
    if (!user || !db) return;
    try {
      await deleteDoc(doc(db, "users", user.uid, "customRoutines", routineId));
      toast({ title: "Routine Scrapped", description: "The program has been removed." });
    } catch (e) {}
  }

  return (
    <AppShell>
      <div className="space-y-10 pb-16">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <h1 className="text-4xl font-headline font-black uppercase tracking-tighter flex items-center gap-3">
              <Hammer className="h-8 w-8 text-primary" />
              The Forge
            </h1>
            <p className="text-muted-foreground text-sm font-medium">Build, refine, and save your custom bodyweight paths.</p>
          </div>
          <Button 
            variant="outline" 
            className="rounded-xl gap-2 font-black uppercase text-[10px] tracking-widest h-12 border-primary/20 bg-primary/5 hover:bg-primary/10 transition-all shadow-xl shadow-primary/5"
            onClick={handleAIGenerate}
            disabled={isGenerating}
          >
            {isGenerating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 fill-primary" />}
            AI Neural Forge
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Builder UI */}
          <div className="lg:col-span-8 space-y-6">
            <Card className="bg-card/50 border-border shadow-2xl">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-headline uppercase font-black">Routine Builder</CardTitle>
                <CardDescription className="text-[10px] uppercase font-bold tracking-widest">Assemble your sequence</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Routine Identity</label>
                  <Input 
                    placeholder="Enter Routine Name (e.g., Morning Mobility)" 
                    className="h-12 rounded-xl bg-background border-border font-bold"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Current Exercises ({selectedExercises.length})</label>
                    {selectedExercises.length > 0 && (
                      <Button variant="ghost" size="sm" className="h-6 text-[8px] font-black uppercase" onClick={() => setSelectedExercises([])}>Clear All</Button>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    {selectedExercises.length === 0 ? (
                      <div className="py-12 border-2 border-dashed border-border rounded-2xl flex flex-col items-center justify-center text-center px-6">
                        <Dumbbell className="h-10 w-10 text-muted-foreground opacity-20 mb-4" />
                        <p className="text-xs font-medium text-muted-foreground">Your sequence is empty. Select exercises from the library below.</p>
                      </div>
                    ) : (
                      selectedExercises.map((ex, idx) => (
                        <div key={idx} className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border group animate-in slide-in-from-right-2 duration-300">
                          <div className="flex items-center gap-4">
                            <span className="text-[10px] font-black opacity-30">{idx + 1}</span>
                            <div>
                              <p className="font-bold uppercase text-xs">{ex.name}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <Input 
                                  type="number" 
                                  className="h-7 w-16 text-center text-[10px] font-black p-0 bg-background" 
                                  value={ex.unit === 'reps' ? ex.reps : ex.seconds}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value) || 0;
                                    const next = [...selectedExercises];
                                    if (ex.unit === 'reps') next[idx].reps = val;
                                    else next[idx].seconds = val;
                                    next[idx].target = `${val} ${ex.unit === 'reps' ? 'Reps' : 'Seconds'}`;
                                    setSelectedExercises(next);
                                  }}
                                />
                                <span className="text-[8px] font-black uppercase opacity-60">{ex.unit}</span>
                              </div>
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => removeExercise(idx)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <Button 
                  className="w-full h-14 rounded-2xl text-lg font-black uppercase tracking-widest gap-3 shadow-2xl shadow-primary/20"
                  onClick={handleSaveRoutine}
                  disabled={isForging || selectedExercises.length === 0}
                >
                  {isForging ? <Loader2 className="h-6 w-6 animate-spin" /> : <Save className="h-6 w-6" />}
                  {isForging ? "Forging..." : "Forge Program"}
                </Button>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  className="pl-11 h-12 rounded-xl bg-card border-border" 
                  placeholder="Search Library for Exercises..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-primary/20">
                {filteredExercises.map((ex) => (
                  <Card 
                    key={ex.id} 
                    className="bg-card/30 border-border hover:border-primary/50 transition-all cursor-pointer group"
                    onClick={() => addExerciseToRoutine(ex)}
                  >
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                          <Dumbbell className="h-5 w-5 text-primary group-hover:scale-110 transition-transform" />
                        </div>
                        <div>
                          <p className="font-bold text-xs uppercase">{ex.name}</p>
                          <p className="text-[8px] font-black uppercase text-muted-foreground">{ex.category} • {ex.level}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-[8px] font-black opacity-60">+{ex.xp} XP</Badge>
                        <Plus className="h-4 w-4 text-primary" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Saved Routines List */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-headline font-black uppercase tracking-widest">Saved Arsenal</h3>
              <Badge variant="secondary" className="text-[10px] font-black">{savedRoutines?.length || 0}</Badge>
            </div>

            <div className="space-y-4">
              {routinesLoading ? (
                <div className="flex justify-center py-20">
                  <Loader2 className="h-8 w-8 text-primary animate-spin" />
                </div>
              ) : savedRoutines && savedRoutines.length > 0 ? (
                savedRoutines.map((routine) => (
                  <Card key={routine.id} className="bg-card/50 border-border overflow-hidden hover:border-primary/30 transition-all group">
                    <CardHeader className="p-4 pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm font-headline uppercase font-black tracking-tight truncate">{routine.name}</CardTitle>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <Zap className="h-3.5 w-3.5 text-muted-foreground" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-40">
                             <DropdownMenuItem 
                              className="text-xs font-bold text-destructive"
                              onSelect={() => handleDeleteRoutine(routine.id)}
                             >
                               <Trash2 className="h-3.5 w-3.5 mr-2" /> Scrap Routine
                             </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">
                        {routine.exercises.length} Movements • Mastery Sequence
                      </p>
                    </CardHeader>
                    <CardContent className="p-4 pt-2">
                      <Button 
                        className="w-full h-10 rounded-xl font-black uppercase text-[10px] tracking-widest gap-2"
                        onClick={() => router.push(`/workout?customId=${routine.id}`)}
                      >
                        <Play className="h-3 w-3 fill-current" /> Initialize Session
                      </Button>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="py-20 text-center space-y-4 border-2 border-dashed border-border rounded-2xl">
                   <Hammer className="h-10 w-10 text-muted-foreground opacity-20 mx-auto" />
                   <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">No custom paths forged yet.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
