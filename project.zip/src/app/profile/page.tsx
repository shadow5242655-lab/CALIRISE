
"use client";

import { useEffect, useState, useMemo } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  User, 
  Shield, 
  Zap, 
  Award, 
  Star, 
  Flame, 
  Trophy, 
  Settings, 
  TrendingUp,
  History,
  BarChart3,
  LineChart
} from "lucide-react";
import { useUser, useDoc } from "@/firebase";
import { BADGES } from "@/lib/progression";
import { cn } from "@/lib/utils";
import { 
  ChartContainer, 
  ChartTooltip, 
  ChartTooltipContent,
  type ChartConfig 
} from "@/components/ui/chart";
import { 
  Line, 
  LineChart as RechartsLineChart, 
  Bar, 
  BarChart as RechartsBarChart, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer 
} from "recharts";

export default function ProfilePage() {
  const { user } = useUser();
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);
  const [localProfile, setLocalProfile] = useState<{ name: string, level: number, xp: number, streak: number, badges?: string[], workouts?: number } | null>(null);

  useEffect(() => {
    // Browser-specific values deferred until after client-side hydration
    const name = localStorage.getItem('ayush_guest_name');
    const level = localStorage.getItem('ayush_selected_level');
    const xp = localStorage.getItem('ayush_xp') || '0';
    const streak = localStorage.getItem('ayush_streak') || '0';
    const workouts = localStorage.getItem('ayush_workouts_count') || '0';
    const badgesStr = localStorage.getItem('ayush_badges');

    setLocalProfile({
      name: name || "Elite Athlete",
      level: level ? parseInt(level) : 0,
      xp: parseInt(xp),
      streak: streak ? parseInt(streak) : 0,
      workouts: parseInt(workouts),
      badges: badgesStr ? JSON.parse(badgesStr) : []
    });
  }, []);

  const stats = {
    name: profile?.displayName || localProfile?.name || "Athlete",
    level: profile?.level || localProfile?.level || 0,
    xp: profile?.xp || localProfile?.xp || 0,
    streak: profile?.streak || localProfile?.streak || 0,
    workouts: profile?.workouts || localProfile?.workouts || 0,
    badges: profile?.badges || localProfile?.badges || []
  };

  const nextLevelXp = (stats.level || 1) * 500;
  const progressPercent = Math.min(100, (stats.xp / nextLevelXp) * 100);

  const xpChartData = useMemo(() => {
    const base = stats.xp > 0 ? stats.xp : 100;
    return [
      { day: "Mon", xp: Math.floor(base * 0.4) },
      { day: "Tue", xp: Math.floor(base * 0.5) },
      { day: "Wed", xp: Math.floor(base * 0.65) },
      { day: "Thu", xp: Math.floor(base * 0.7) },
      { day: "Fri", xp: Math.floor(base * 0.85) },
      { day: "Sat", xp: Math.floor(base * 0.95) },
      { day: "Sun", xp: base },
    ];
  }, [stats.xp]);

  const activityData = useMemo(() => {
    return [
      { day: "Mon", sessions: 1 },
      { day: "Tue", sessions: 0 },
      { day: "Wed", sessions: 2 },
      { day: "Thu", sessions: 1 },
      { day: "Fri", sessions: 1 },
      { day: "Sat", sessions: 0 },
      { day: "Sun", sessions: 1 },
    ];
  }, []);

  const chartConfig: ChartConfig = {
    xp: {
      label: "Power Score",
      color: "hsl(var(--primary))",
    },
    sessions: {
      label: "Sessions",
      color: "hsl(var(--accent))",
    }
  };

  return (
    <AppShell>
      <div className="max-w-5xl mx-auto space-y-8 pb-12">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-4xl font-headline font-black uppercase tracking-tighter">Athlete Dossier</h1>
            <p className="text-muted-foreground text-sm font-medium">Visualized mastery progress and biometric data.</p>
          </div>
          <Button variant="outline" size="icon" className="rounded-xl border-border h-12 w-12">
            <Settings className="h-5 w-5" />
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Identity Card */}
          <div className="lg:col-span-4 space-y-6">
            <Card className="bg-card/50 border-border overflow-hidden shadow-2xl">
              <div className="h-32 bg-primary relative">
                <div className="absolute top-0 right-0 p-4 opacity-20">
                  <Trophy className="h-20 w-20 text-white" />
                </div>
              </div>
              <CardContent className="pt-0 -mt-12 flex flex-col items-center text-center space-y-4 pb-8">
                <div className="h-24 w-24 rounded-3xl bg-background border-4 border-card flex items-center justify-center shadow-2xl">
                  {user?.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="h-full w-full object-cover rounded-2xl" />
                  ) : (
                    <User className="h-12 w-12 text-primary" />
                  )}
                </div>
                <div>
                  <h2 className="text-2xl font-headline font-black uppercase tracking-tight">{stats.name}</h2>
                  <p className="text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em] opacity-60">Mastery Path Protocol Active</p>
                </div>
                <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest">
                  <Shield className="h-3.5 w-3.5" />
                  Rank {stats.level} Warrior
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border shadow-xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-headline uppercase font-black flex items-center gap-2 tracking-widest">
                  <TrendingUp className="h-4 w-4 text-accent" />
                  Vital Biometrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground font-black uppercase text-[10px] tracking-widest">Workouts</span>
                  <span className="font-black font-headline text-lg">{stats.workouts}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground font-black uppercase text-[10px] tracking-widest">Streak</span>
                  <div className="flex items-center gap-1.5 text-orange-500">
                    <Flame className="h-4 w-4 fill-orange-500" />
                    <span className="font-black font-headline text-lg">{stats.streak}D</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground font-black uppercase text-[10px] tracking-widest">Power Score</span>
                  <span className="font-black font-headline text-lg text-primary">{stats.xp.toLocaleString()}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <CardTitle className="text-lg font-headline uppercase font-black tracking-tighter">Hall of Mastery</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="grid grid-cols-2 gap-3">
                  {BADGES.slice(0, 4).map((badge) => {
                    const isEarned = stats.badges.includes(badge.id);
                    return (
                      <div 
                        key={badge.id} 
                        className={cn(
                          "p-4 rounded-2xl border flex flex-col items-center text-center gap-1.5 transition-all",
                          isEarned 
                            ? "bg-accent/10 border-accent/30 text-accent" 
                            : "bg-secondary/20 border-border opacity-20 grayscale"
                        )}
                      >
                         <Star className={cn("h-4 w-4 mb-1", isEarned ? "fill-accent" : "text-muted-foreground")} />
                         <p className="text-[8px] font-black uppercase tracking-tighter leading-tight">{badge.name}</p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress & Data Insights */}
          <div className="lg:col-span-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* XP Growth Chart */}
              <Card className="bg-card/50 border-border shadow-xl">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-[10px] font-headline uppercase font-black tracking-[0.2em] flex items-center gap-2">
                        <LineChart className="h-4 w-4 text-primary" />
                        XP Progression
                      </CardTitle>
                      <CardDescription className="text-[8px] uppercase font-bold tracking-widest text-muted-foreground">7-Day Growth Curve</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="h-48 pt-4">
                  <ChartContainer config={chartConfig} className="h-full w-full">
                    <RechartsLineChart data={xpChartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="day" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fontSize: 9, fontWeight: 900, fill: "hsl(var(--muted-foreground))"}} 
                        dy={10}
                      />
                      <YAxis hide />
                      <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                      <Line 
                        type="monotone" 
                        dataKey="xp" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={4} 
                        dot={{fill: "hsl(var(--primary))", r: 4, strokeWidth: 0}} 
                        activeDot={{r: 6, strokeWidth: 0}}
                      />
                    </RechartsLineChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Activity Volume Chart */}
              <Card className="bg-card/50 border-border shadow-xl">
                <CardHeader className="pb-2">
                  <div className="space-y-1">
                    <CardTitle className="text-[10px] font-headline uppercase font-black tracking-[0.2em] flex items-center gap-2">
                      <BarChart3 className="h-4 w-4 text-accent" />
                      Weekly Activity
                    </CardTitle>
                    <CardDescription className="text-[8px] uppercase font-bold tracking-widest text-muted-foreground">Workout Volume Frequency</CardDescription>
                  </div>
                </CardHeader>
                <CardContent className="h-48 pt-4">
                  <ChartContainer config={chartConfig} className="h-full w-full">
                    <RechartsBarChart data={activityData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="day" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fontSize: 9, fontWeight: 900, fill: "hsl(var(--muted-foreground))"}} 
                        dy={10}
                      />
                      <YAxis hide />
                      <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                      <Bar 
                        dataKey="sessions" 
                        fill="hsl(var(--accent))" 
                        radius={[6, 6, 0, 0]} 
                      />
                    </RechartsBarChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-card/50 border-border shadow-2xl border-t-primary/20">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-headline uppercase font-black tracking-tighter">Level {stats.level} Mastery Track</CardTitle>
                  <span className="text-xs font-black uppercase text-primary">{stats.xp} / {nextLevelXp} XP</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="h-5 bg-secondary rounded-full overflow-hidden border border-border p-1">
                    <div 
                      className="h-full bg-primary transition-all duration-1000 ease-out shadow-[0_0_20px_rgba(59,130,246,0.5)] rounded-full" 
                      style={{ width: `${progressPercent}%` }} 
                    />
                  </div>
                  <p className="text-[10px] text-center text-muted-foreground font-black uppercase tracking-[0.2em] italic">
                    {100 - Math.round(progressPercent)}% to Rank Advancement
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border border-dashed">
              <CardHeader>
                 <div className="flex items-center gap-2">
                    <History className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg font-headline uppercase font-black tracking-tighter">Recent Activity Log</CardTitle>
                 </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center justify-between p-5 rounded-2xl bg-secondary/20 border border-border/50 hover:bg-secondary/40 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Zap className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <p className="text-xs font-black uppercase tracking-tight">Bodyweight Session Complete</p>
                          <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest mt-0.5">Intensity: High • {i} day ago</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[10px] font-black text-primary border-primary/20 bg-primary/5">+250 XP</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
