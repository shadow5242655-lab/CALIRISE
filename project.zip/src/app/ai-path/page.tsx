
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, Loader2, CheckCircle2, Trophy, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { LEVELS } from "@/lib/progression";
import { cn } from "@/lib/utils";

export default function SelectPathPage() {
  const [saving, setSaving] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [localWorkouts, setLocalWorkouts] = useState<number>(0);
  const [localLevel, setLocalLevel] = useState<number>(0);
  const { user } = useUser();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);

  useEffect(() => {
    const savedWorkouts = localStorage.getItem('ayush_workouts_count');
    const savedLevel = localStorage.getItem('ayush_selected_level');
    
    if (savedWorkouts) setLocalWorkouts(parseInt(savedWorkouts));
    if (savedLevel) setLocalLevel(parseInt(savedLevel));
  }, []);

  useEffect(() => {
    if (profile?.level) {
      setSelectedId(profile.level);
    } else if (localLevel) {
      setSelectedId(localLevel);
    }
  }, [profile, localLevel]);

  const totalWorkouts = profile?.workouts ?? localWorkouts;
  const currentLevel = profile?.level ?? localLevel;

  function handleSaveAndStart() {
    if (selectedId === null) {
      toast({ title: "Select a Path", description: "Please choose your mastery level first." });
      return;
    }
    
    setSaving(true);

    const xp = profile?.xp ?? parseInt(localStorage.getItem('ayush_xp') || '0');
    const streak = profile?.streak ?? parseInt(localStorage.getItem('ayush_streak') || '0');
    const athleteName = localStorage.getItem('ayush_guest_name') || "Athlete";

    // Save locally
    localStorage.setItem('ayush_selected_level', selectedId.toString());
    localStorage.setItem('ayush_workouts_count', '0');

    // Save to Firestore if available
    if (user && db) {
      const userRef = doc(db, "users", user.uid);
      setDoc(userRef, {
        level: selectedId,
        workouts: 0,
        xp: xp,
        streak: streak,
        displayName: athleteName,
        email: user.email || ""
      }, { merge: true })
        .catch(() => {});
    }

    toast({ 
      title: "Path Forged!", 
      description: `Your ${LEVELS.find(l => l.id === selectedId)?.name} journey has begun at Day 1.` 
    });

    router.push("/");
  }

  return (
    <AppShell>
      <div className="max-w-4xl mx-auto space-y-10 py-12 px-4">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest mb-2">
            <Trophy className="h-3 w-3" />
            Mastery Path Selection
          </div>
          <h1 className="text-4xl md:text-5xl font-headline font-black mb-2 uppercase tracking-tighter">Forge Your Path</h1>
          <p className="text-muted-foreground text-sm md:text-lg max-w-2xl mx-auto font-medium">
            Choose your starting point. Higher paths unlock only after you master your current 30-day program.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {LEVELS.map((level) => {
            const isFreshStart = currentLevel === 0;
            const isCurrent = currentLevel === level.id;
            const isFinishedPrevious = currentLevel > 0 && totalWorkouts >= 30 && level.id === currentLevel + 1;
            const isLowerThanCurrent = currentLevel > 0 && level.id < currentLevel;
            
            const isLocked = !isFreshStart && !isCurrent && !isFinishedPrevious && !isLowerThanCurrent;

            return (
              <Card 
                key={level.id} 
                className={cn(
                  "relative cursor-pointer transition-all duration-500 overflow-hidden border-2 bg-card/50",
                  selectedId === level.id 
                    ? "border-primary bg-primary/5 ring-8 ring-primary/5 scale-[1.02]" 
                    : "border-border hover:border-primary/40",
                  isLocked && "opacity-40 grayscale cursor-not-allowed pointer-events-none"
                )}
                onClick={() => !isLocked && setSelectedId(level.id)}
              >
                {isLocked && (
                  <div className="absolute top-4 right-4 z-10">
                    <Lock className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className={cn("text-2xl font-headline font-black uppercase", level.color)}>
                      {level.name}
                    </CardTitle>
                    {selectedId === level.id && (
                      <div className="bg-primary rounded-full p-1.5 shadow-lg shadow-primary/20">
                        <CheckCircle2 className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                  <CardDescription className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">{level.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-4">
                  <p className="text-[10px] text-primary font-black uppercase leading-relaxed tracking-widest">
                    INITIAL FOCUS: {level.plan[0].focus}
                  </p>
                  <ul className="space-y-2">
                    {level.plan[0].exercises.slice(0, 3).map((ex: any, idx: number) => (
                      <li key={idx} className="text-[10px] text-muted-foreground flex items-center gap-3 font-bold uppercase tracking-tight">
                        <div className={cn("h-1.5 w-1.5 rounded-full", level.color.replace('text-', 'bg-'))} />
                        {ex.name}
                      </li>
                    ))}
                  </ul>
                  {isCurrent && !isLocked && (
                    <div className="mt-4 px-3 py-1 bg-primary text-primary-foreground text-[8px] font-black uppercase rounded-full w-fit tracking-widest">
                      Active Program
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="flex flex-col items-center gap-6 pt-10">
          <Button 
            className={cn(
              "w-full max-w-sm h-16 rounded-2xl text-xl font-black uppercase tracking-widest gap-4 shadow-2xl transition-all",
              selectedId !== null 
                ? "bg-primary text-primary-foreground shadow-primary/20 scale-105 hover:scale-110 active:scale-95" 
                : "bg-muted text-muted-foreground grayscale cursor-not-allowed"
            )}
            onClick={handleSaveAndStart}
            disabled={selectedId === null || saving}
          >
            {saving ? <Loader2 className="h-6 w-6 animate-spin" /> : <Sparkles className="h-6 w-6 fill-current" />}
            {saving ? "Initializing..." : `Forge Path`}
          </Button>
          {currentLevel > 0 && totalWorkouts < 30 && (
            <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest opacity-60">
              Complete {30 - totalWorkouts} more sessions to unlock higher tiers.
            </p>
          )}
        </div>
      </div>
    </AppShell>
  );
}
