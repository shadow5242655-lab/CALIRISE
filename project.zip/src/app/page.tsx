
"use client";

import { useState, useEffect, useMemo } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { StatCards } from "@/components/dashboard/StatCards";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Play, 
  TrendingUp, 
  Youtube, 
  Sparkles,
  ArrowRight,
  Loader2,
  Lock,
  Flame,
  Award,
  Trophy,
  Zap
} from "lucide-react";
import Link from "next/link";
import { useUser, useDoc } from "@/firebase";
import { cn } from "@/lib/utils";
import { LEVELS, CHALLENGES } from "@/lib/progression";

export default function Dashboard() {
  const { user, loading: authLoading } = useUser();
  const { data: profile, loading: profileLoading } = useDoc(user ? `users/${user.uid}` : null);
  
  const [localStats, setLocalStats] = useState({
    level: 0,
    workouts: 0,
    streak: 0,
    initialized: false
  });
  
  useEffect(() => {
    const savedLevel = localStorage.getItem('ayush_selected_level');
    const savedWorkouts = localStorage.getItem('ayush_workouts_count');
    const savedStreak = localStorage.getItem('ayush_streak');
    
    setLocalStats({
      level: savedLevel ? parseInt(savedLevel) : 0,
      workouts: savedWorkouts ? parseInt(savedWorkouts) : 0,
      streak: savedStreak ? parseInt(savedStreak) : 0,
      initialized: true
    });
  }, []);

  const currentLevel = useMemo(() => profile?.level || localStats.level || 0, [profile, localStats]);
  const currentLevelData = useMemo(() => LEVELS.find(l => l.id === currentLevel), [currentLevel]);
  const totalWorkouts = useMemo(() => profile?.workouts ?? localStats.workouts, [profile, localStats]);
  const streakCount = useMemo(() => profile?.streak ?? localStats.streak, [profile, localStats]);
  
  const isPathComplete = totalWorkouts >= 30;

  if (!localStats.initialized && !authLoading) {
    return (
      <AppShell>
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="h-8 w-8 text-primary animate-spin" />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="space-y-6 md:space-y-10 pb-16">
        {!currentLevel ? (
          <div className="flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-border/50 rounded-3xl bg-secondary/5 space-y-6 max-w-lg mx-auto animate-in fade-in zoom-in-95 duration-500">
            <Sparkles className="h-12 w-12 text-primary animate-pulse" />
            <div className="space-y-2 px-6">
              <h2 className="text-2xl font-headline font-black uppercase tracking-tighter">Forge Your Path</h2>
              <p className="text-muted-foreground text-xs font-medium leading-relaxed">
                To unlock your personalized 30-day training regimen and track your progress, you must first select a mastery path.
              </p>
            </div>
            <Button className="rounded-xl px-10 h-12 text-sm font-black uppercase gap-2 shadow-2xl shadow-primary/20" asChild>
              <Link href="/ai-path">Select Path <ArrowRight className="h-4 w-4" /></Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-5 md:space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex items-center justify-between px-2">
              <div className="space-y-1">
                <p className="text-[10px] font-black uppercase text-primary tracking-widest">Active Program</p>
                <div className="flex items-center gap-3">
                  <h2 className={cn("text-xl md:text-3xl font-headline font-black uppercase tracking-tighter", currentLevelData?.color)}>
                    {currentLevelData?.name} Journey
                  </h2>
                  {streakCount > 0 && (
                    <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-500 animate-pulse">
                      <Flame className="h-4 w-4 fill-orange-500" />
                      <span className="text-xs font-black">{streakCount}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-secondary/50 border border-border">
                   <Trophy className="h-3.5 w-3.5 text-yellow-500" />
                   <span className="text-[10px] font-black uppercase">Global Rank: #852</span>
                </div>
                {isPathComplete ? (
                  <Button variant="outline" size="sm" className="rounded-lg text-[9px] font-black uppercase h-8 border-primary/20 bg-primary/5 hover:bg-primary/10" asChild>
                    <Link href="/ai-path">Change Path</Link>
                  </Button>
                ) : (
                  <div className="flex items-center gap-2 px-2 md:px-3 py-1 md:py-1.5 rounded-lg border border-border bg-secondary/20 opacity-60">
                    <Lock className="h-3 w-3 text-muted-foreground" />
                    <span className="text-[8px] font-black uppercase tracking-tighter text-muted-foreground">Locked ({totalWorkouts}/30)</span>
                  </div>
                )}
              </div>
            </div>

            <StatCards />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between px-2">
                  <h3 className="text-sm font-headline font-bold uppercase tracking-tight flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    30-Day Blueprint
                  </h3>
                  <p className="text-[10px] font-bold uppercase text-muted-foreground">Progress: {Math.min(100, Math.round((totalWorkouts / 30) * 100))}%</p>
                </div>

                <div className="grid gap-3 max-h-[500px] md:max-h-[600px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-primary/20">
                  {currentLevelData?.plan.map((dayPlan: any, idx: number) => {
                    const isDayDone = totalWorkouts > idx;
                    return (
                      <Card key={idx} className={cn("bg-card/50 border-border overflow-hidden group hover:border-primary/30 transition-colors", isDayDone && "opacity-60 grayscale-[0.5]")}>
                        <CardHeader className="bg-secondary/20 py-2 md:py-2.5 px-4 md:px-6 flex flex-row items-center justify-between border-b border-border">
                          <div>
                            <CardTitle className="text-xs font-headline uppercase tracking-widest flex items-center gap-2">
                              {dayPlan.day}
                              {isDayDone && <div className="h-1.5 w-1.5 rounded-full bg-emerald-500" />}
                            </CardTitle>
                            <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest">{dayPlan.focus}</p>
                          </div>
                          {dayPlan.exercises.length > 0 && !isDayDone && (
                            <Button size="sm" className="h-7 px-3 text-[9px] font-black gap-2 rounded-lg" asChild>
                              <Link href={`/workout?day=${idx + 1}`}><Play className="h-3 w-3 fill-current" /> START</Link>
                            </Button>
                          )}
                        </CardHeader>
                        <CardContent className="p-3 md:p-4">
                          {dayPlan.exercises.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {dayPlan.exercises.map((ex: any, exIdx: number) => (
                                <div key={exIdx} className="flex items-center justify-between p-2 rounded-lg bg-secondary/10 border border-border/40 hover:bg-secondary/20 transition-colors">
                                  <div className="space-y-0.5">
                                    <p className="font-bold text-[10px] uppercase truncate max-w-[120px] md:max-w-none">{ex.name}</p>
                                    <p className="text-[8px] text-accent font-black uppercase">{ex.target}</p>
                                  </div>
                                  <Button variant="ghost" size="icon" className="h-6 w-6 p-0 rounded-full text-red-500 hover:bg-red-500/10" onClick={() => window.open(ex.link, '_blank')}><Youtube className="h-3.5 w-3.5" /></Button>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-[9px] font-black uppercase text-center py-4 text-emerald-500">Recovery & Mobility - Focus on technique</p>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-4 md:space-y-6">
                <Card className="bg-primary text-primary-foreground shadow-2xl shadow-primary/20 border-none overflow-hidden">
                  <CardHeader className="pb-2 md:pb-3">
                    <CardTitle className="font-headline text-base uppercase font-black">Today's Mission</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 md:space-y-4">
                    <p className="text-[10px] opacity-90 font-medium leading-relaxed">
                      {totalWorkouts < 30 ? `Session ${totalWorkouts + 1} awaits. Complete all 30 days to unlock the next mastery path.` : "Program Complete! You have earned the right to choose a new path."}
                    </p>
                    <Button className="w-full bg-background text-foreground hover:bg-background/90 rounded-xl gap-2 font-black h-10 md:h-11 uppercase text-[10px] tracking-widest" asChild>
                      <Link href={isPathComplete ? "/ai-path" : `/workout?day=${totalWorkouts + 1}`}>
                        {isPathComplete ? (<>ASCEND PATH <ArrowRight className="h-3 w-3" /></>) : (<><Play className="h-3 w-3 fill-current" /> START TRAINING</>)}
                      </Link>
                    </Button>
                  </CardContent>
                </Card>

                {/* Challenge Summary */}
                <Card className="bg-card/50 border-border border-dashed">
                  <CardHeader className="pb-2 flex flex-row items-center justify-between">
                    <CardTitle className="text-[10px] uppercase font-black tracking-[0.2em]">Active Challenge</CardTitle>
                    <Zap className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-1">
                      <p className="text-xs font-bold uppercase">{CHALLENGES[0].name}</p>
                      <p className="text-[10px] text-muted-foreground leading-tight">{CHALLENGES[0].description}</p>
                    </div>
                    <div className="space-y-1.5">
                       <div className="flex justify-between text-[8px] font-black uppercase tracking-widest">
                          <span>Progress</span>
                          <span>{Math.round((totalWorkouts * 15 / CHALLENGES[0].target) * 100)}%</span>
                       </div>
                       <div className="h-1 bg-secondary rounded-full overflow-hidden">
                          <div className="h-full bg-primary" style={{ width: `${Math.round((totalWorkouts * 15 / CHALLENGES[0].target) * 100)}%` }} />
                       </div>
                    </div>
                    <Button variant="ghost" size="sm" className="w-full h-8 text-[9px] font-black uppercase gap-2 hover:bg-primary/10" asChild>
                       <Link href="/community">Join Global Feed <ArrowRight className="h-3 w-3" /></Link>
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 border-border">
                  <CardHeader className="pb-2 flex flex-row items-center justify-between">
                    <CardTitle className="text-xs uppercase font-black tracking-widest">Athlete Rank</CardTitle>
                    <Award className="h-4 w-4 text-primary" />
                  </CardHeader>
                  <CardContent>
                    <p className="text-[10px] text-muted-foreground leading-relaxed italic">
                      "Form is temporary, mechanics are eternal. Never sacrifice a single rep for speed."
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
