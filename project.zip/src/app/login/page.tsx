
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dumbbell, Loader2, ArrowRight, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function LoginPage() {
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const router = useRouter();
  const { toast } = useToast();

  async function handleGuestSignIn(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast({ title: "Name Required", description: "Please enter your athlete name to forge your identity." });
      return;
    }
    
    setLoading(true);
    
    // Simulate profile initialization
    setTimeout(() => {
      localStorage.setItem('ayush_guest_mode', 'true');
      localStorage.setItem('ayush_guest_name', name.trim());
      
      // Initialize core stats if not present
      if (!localStorage.getItem('ayush_xp')) localStorage.setItem('ayush_xp', '0');
      if (!localStorage.getItem('ayush_streak')) localStorage.setItem('ayush_streak', '0');
      if (!localStorage.getItem('ayush_workouts_count')) localStorage.setItem('ayush_workouts_count', '0');
      if (!localStorage.getItem('ayush_selected_level')) localStorage.setItem('ayush_selected_level', '0');

      toast({ 
        title: "Identity Forged", 
        description: `Welcome to AYURISE, ${name.trim()}. Your path awaits.` 
      });
      
      router.push("/ai-path");
      setLoading(false);
    }, 1000);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background overflow-hidden">
      <div className="w-full max-w-md space-y-8 py-8 animate-in fade-in slide-in-from-bottom-4 duration-1000">
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="p-4 bg-primary rounded-3xl shadow-2xl shadow-primary/20 rotate-3 hover:rotate-0 transition-transform duration-500">
            <Dumbbell className="h-10 w-10 text-primary-foreground" />
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-headline font-black tracking-tighter uppercase text-primary">AYURISE</h1>
            <p className="text-muted-foreground text-[10px] font-black uppercase tracking-[0.3em] opacity-80">Bodyweight Mastery System</p>
          </div>
        </div>

        <Card className="bg-card/40 border-border shadow-2xl backdrop-blur-xl border-t-primary/20">
          <form onSubmit={handleGuestSignIn}>
            <CardHeader className="p-8 text-center space-y-2">
              <CardTitle className="font-headline text-2xl uppercase tracking-tighter">Forge Identity</CardTitle>
              <p className="text-xs text-muted-foreground font-medium">Initialize your local mastery profile to begin training.</p>
            </CardHeader>
            <CardContent className="space-y-6 p-8 pt-0">
              <div className="space-y-3">
                <Label htmlFor="name" className="text-[10px] font-black uppercase tracking-widest ml-1 text-primary/70">
                  Athlete Name
                </Label>
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
                  <Input 
                    id="name" 
                    placeholder="Enter Rank Name..." 
                    className="h-14 pl-12 rounded-2xl bg-background/50 border-border font-black text-lg focus:ring-primary/20" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    autoFocus
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="p-8">
              <Button 
                type="submit"
                className="w-full h-16 rounded-2xl text-xl font-black uppercase tracking-widest gap-4 shadow-2xl shadow-primary/20 transition-all hover:scale-[1.02] active:scale-[0.98]" 
                disabled={loading}
              >
                {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : <ArrowRight className="h-6 w-6" />}
                {loading ? "Forging..." : "Forge Identity"}
              </Button>
            </CardFooter>
          </form>
        </Card>

        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/50 border border-border text-[9px] font-black uppercase tracking-widest text-muted-foreground">
             <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
             Local Encryption Active
          </div>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-black opacity-30">
            Training is sacrifice. Progress is eternal.
          </p>
        </div>
      </div>
    </div>
  );
}
