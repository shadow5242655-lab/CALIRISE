
"use client";

import { useState, useEffect, useMemo, Suspense, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Pause, 
  SkipForward, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  Youtube,
  ChevronLeft,
  Loader2,
  Volume2,
  VolumeX,
  Target,
  PlayCircle,
  Share2,
  Trophy,
  Play
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { useUser, useDoc, useFirestore } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { LEVELS } from "@/lib/progression";
import { getWgerExerciseInfo, type WgerExercise } from "@/lib/wger-service";
import Link from "next/link";

const SOUNDS = {
  BEEP: "https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3",
  FINISH: "https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3",
  SUCCESS: "https://assets.mixkit.co/active_storage/sfx/2020/2020-preview.mp3",
  START: "https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3"
};

function WorkoutSessionContent() {
  const { user } = useUser();
  const db = useFirestore();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);
  
  const [localWorkouts, setLocalWorkouts] = useState(0);
  useEffect(() => {
    const saved = localStorage.getItem('ayush_workouts_count');
    if (saved) setLocalWorkouts(parseInt(saved));
  }, []);

  const totalWorkoutsCompleted = profile?.workouts ?? localWorkouts;
  const requestedDay = parseInt(searchParams.get("day") || (totalWorkoutsCompleted + 1).toString());
  
  const [active, setActive] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [muted, setMuted] = useState(false);
  const [exerciseInfo, setExerciseInfo] = useState<WgerExercise | null>(null);
  const { toast } = useToast();

  const sessionData = useMemo(() => {
    const levelId = profile?.level || parseInt(localStorage.getItem('ayush_selected_level') || '1');
    const currentPath = LEVELS.find(l => l.id === levelId) || LEVELS[0];
    const dayIndex = Math.max(0, requestedDay - 1);
    const dayPlan = currentPath.plan[dayIndex] || currentPath.plan[0];
    const items: any[] = [];
    
    if (dayPlan.exercises.length === 0) {
      return [{ name: "Active Recovery", duration: 300, type: "Rest", unit: 'seconds', wgerId: 0 }];
    }

    dayPlan.exercises.forEach((ex: any, idx: number) => {
      items.push({
        id: `ex-${idx}`,
        name: ex.name,
        duration: ex.seconds || 45,
        reps: ex.reps,
        unit: !!ex.reps ? 'reps' : 'seconds',
        type: "Work",
        wgerId: ex.wgerId,
        videoUrl: ex.link,
      });
      if (idx < dayPlan.exercises.length - 1) {
        items.push({ id: `rest-${idx}`, name: "Rest", duration: 60, unit: 'seconds', type: "Rest", wgerId: 0 });
      }
    });
    return items;
  }, [profile?.level, requestedDay]);

  const currentExercise = sessionData[currentIndex];
  const [timeLeft, setTimeLeft] = useState(currentExercise.duration);

  useEffect(() => {
    async function loadInfo() {
      if (currentExercise.wgerId > 0) {
        try {
          const info = await getWgerExerciseInfo(currentExercise.wgerId);
          setExerciseInfo(info);
        } catch (e) {
          setExerciseInfo(null);
        }
      } else {
        setExerciseInfo(null);
      }
    }
    loadInfo();
  }, [currentExercise]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (active && currentExercise.unit === 'seconds' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev: number) => prev - 1);
        setElapsed((prev) => prev + 1);
      }, 1000);
    } else if (active && currentExercise.unit === 'seconds' && timeLeft === 0) {
      handleNext();
    } else if (active && currentExercise.unit === 'reps') {
       timer = setInterval(() => setElapsed((prev) => prev + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [active, timeLeft, currentExercise.unit]);

  function handleNext() {
    if (currentIndex < sessionData.length - 1) {
      const nextIndex = currentIndex + 1;
      setCurrentIndex(nextIndex);
      setTimeLeft(sessionData[nextIndex].duration);
    } else {
      finishWorkout();
    }
  }

  function finishWorkout() {
    setActive(false);
    setIsFinished(true);
    const xpEarned = 250;
    const currentXp = profile?.xp ?? parseInt(localStorage.getItem('ayush_xp') || '0');
    const workoutsCount = (profile?.workouts || parseInt(localStorage.getItem('ayush_workouts_count') || '0')) + 1;
    
    if (user && db) {
      setDoc(doc(db, "users", user.uid), {
        xp: currentXp + xpEarned,
        workouts: workoutsCount,
      }, { merge: true }).catch(() => {});
    } else {
      localStorage.setItem('ayush_xp', (currentXp + xpEarned).toString());
      localStorage.setItem('ayush_workouts_count', workoutsCount.toString());
    }

    toast({ title: "Session Mastered!", description: `+${xpEarned} XP Earned.` });
  }

  function formatTime(seconds: number) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  if (isFinished) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 animate-in fade-in max-w-lg mx-auto">
         <div className="h-20 w-20 rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
            <Trophy className="h-10 w-10 text-emerald-500" />
         </div>
         <h1 className="text-4xl font-headline font-black uppercase tracking-tighter">Day {requestedDay} Mastered</h1>
         <div className="grid grid-cols-2 gap-4 w-full">
            <Card className="p-5 bg-primary text-primary-foreground text-center border-none">
               <p className="text-[10px] font-black uppercase opacity-80">XP Reward</p>
               <p className="text-3xl font-black">+250</p>
            </Card>
            <Card className="p-5 bg-secondary text-center border-border">
               <p className="text-[10px] font-black uppercase opacity-60">Time</p>
               <p className="text-3xl font-black">{formatTime(elapsed)}</p>
            </Card>
         </div>
         <Button className="w-full h-14 font-black uppercase tracking-widest rounded-xl" asChild>
           <Link href="/"><Share2 className="h-4 w-4 mr-2" /> Continue Mission</Link>
         </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="flex items-center justify-between border-b border-border pb-4">
         <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Link href="/" className="hover:text-primary transition-colors"><ChevronLeft className="h-5 w-5" /></Link>
              <h1 className="text-xl font-headline font-black uppercase tracking-tighter">
                Mission Day {requestedDay}
              </h1>
            </div>
         </div>
         <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setMuted(!muted)}>
              {muted ? <VolumeX className="h-4 w-4 text-red-500" /> : <Volume2 className="h-4 w-4 text-primary" />}
            </Button>
            <div className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
               {formatTime(elapsed)}
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         <div className="lg:col-span-2">
            <Card className={cn(
              "relative flex flex-col items-center justify-center text-center p-8 min-h-[500px] border-2 transition-all",
              currentExercise.type === "Rest" ? "bg-emerald-500/5 border-emerald-500/20" : "bg-card/50 border-border"
            )}>
               <Badge className="mb-6 uppercase text-[9px] tracking-widest font-black bg-primary">
                  {currentExercise.type}
               </Badge>
               <h3 className="text-3xl md:text-5xl font-headline font-black uppercase tracking-tighter mb-2">
                  {currentExercise.name}
               </h3>
               
               {exerciseInfo && (
                 <div 
                   className="text-[10px] text-muted-foreground max-w-sm mb-8 line-clamp-2 italic"
                   dangerouslySetInnerHTML={{ __html: exerciseInfo.description }}
                 />
               )}

               <div className="relative mb-10">
                  {currentExercise.unit === 'reps' ? (
                    <div className="flex flex-col items-center">
                      <h2 className="text-8xl font-headline font-black text-primary">{currentExercise.reps}</h2>
                      <p className="text-[10px] font-black uppercase opacity-60">Reps to Complete</p>
                    </div>
                  ) : (
                    <h2 className="text-9xl font-headline font-black tabular-nums">{timeLeft}</h2>
                  )}
               </div>

               <div className="flex items-center gap-6">
                 {currentExercise.unit === 'seconds' && (
                    <Button variant="outline" size="icon" className="h-12 w-12 rounded-full" onClick={() => setTimeLeft(currentExercise.duration)}>
                       <RotateCcw className="h-5 w-5" />
                    </Button>
                 )}
                 <Button className="h-20 w-20 rounded-full" onClick={currentExercise.unit === 'reps' ? handleNext : () => setActive(!active)}>
                    {currentExercise.unit === 'reps' ? <CheckCircle2 className="h-10 w-10" /> : active ? <Pause className="h-10 w-10" /> : <Play className="h-10 w-10 ml-1" />}
                 </Button>
                 <Button variant="outline" size="icon" className="h-12 w-12 rounded-full" onClick={handleNext}>
                    <SkipForward className="h-5 w-5" />
                 </Button>
               </div>
            </Card>
         </div>
         
         <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Session Flow</h4>
              <span className="text-[10px] font-black text-primary">{currentIndex + 1} / {sessionData.length}</span>
            </div>
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-border">
               {sessionData.map((ex, idx) => (
                  <div key={idx} className={cn(
                    "p-4 rounded-xl border flex items-center justify-between",
                    idx === currentIndex ? "bg-primary text-primary-foreground border-primary" : idx < currentIndex ? "opacity-40" : "bg-card/50 border-border opacity-60"
                  )}>
                     <div className="flex items-center gap-3">
                        <span className="text-[10px] font-black opacity-50">{idx + 1}</span>
                        <div>
                           <p className="font-bold uppercase text-[10px]">{ex.name}</p>
                           <p className="text-[8px] font-black uppercase opacity-70">{ex.unit === 'reps' ? `${ex.reps} Reps` : `${ex.duration}s`}</p>
                        </div>
                     </div>
                     {idx < currentIndex && <CheckCircle2 className="h-3 w-3 text-emerald-500" />}
                  </div>
               ))}
            </div>
         </div>
      </div>
    </div>
  );
}

export default function WorkoutSessionPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><Loader2 className="h-10 w-10 text-primary animate-spin" /></div>}>
      <AppShell><WorkoutSessionContent /></AppShell>
    </Suspense>
  );
}
