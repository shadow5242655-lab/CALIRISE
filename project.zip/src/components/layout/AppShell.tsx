
"use client";

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  Dumbbell, 
  BookOpen, 
  Utensils, 
  LayoutDashboard,
  Flame,
  User,
  LogOut,
  Shield,
  Zap,
  ChevronRight,
  Award,
  Star,
  PlayCircle,
  Users,
  Trophy
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { useUser, useAuth, useDoc } from '@/firebase';
import { Button } from '@/components/ui/button';
import { signOut } from 'firebase/auth';
import { BADGES } from '@/lib/progression';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const navItems = [
  { name: 'Home', icon: LayoutDashboard, path: '/' },
  { name: 'Training', icon: PlayCircle, path: '/workout' },
  { name: 'Library', icon: BookOpen, path: '/library' },
  { name: 'Fuel', icon: Utensils, path: '/nutrition' },
  { name: 'Community', icon: Users, path: '/community' },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, loading: authLoading } = useUser();
  const auth = useAuth();
  
  const [localProfile, setLocalProfile] = useState<{ name: string, level: number, xp: number, streak: number, badges?: string[] } | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);

  useEffect(() => {
    const name = localStorage.getItem('ayush_guest_name');
    const level = localStorage.getItem('ayush_selected_level');
    const xp = localStorage.getItem('ayush_xp') || '0';
    const streak = localStorage.getItem('ayush_streak') || '0';
    const badgesStr = localStorage.getItem('ayush_badges');

    setLocalProfile({
      name: name || "Athlete",
      level: level ? parseInt(level) : 0,
      xp: parseInt(xp),
      streak: streak ? parseInt(streak) : 0,
      badges: badgesStr ? JSON.parse(badgesStr) : []
    });
  }, []);

  async function handleLogout() {
    localStorage.removeItem('ayush_guest_mode');
    localStorage.removeItem('ayush_selected_level');
    localStorage.removeItem('ayush_guest_name');
    if (auth) {
      await signOut(auth);
    }
    router.push('/login');
  }

  const effectiveName = useMemo(() => profile?.displayName || localProfile?.name || "Athlete", [profile, localProfile]);
  const effectiveLevel = useMemo(() => profile?.level || localProfile?.level || 0, [profile, localProfile]);
  const effectiveXp = useMemo(() => profile?.xp || localProfile?.xp || 0, [profile, localProfile]);
  const effectiveStreak = useMemo(() => profile?.streak || localProfile?.streak || 0, [profile, localProfile]);
  const earnedBadges = useMemo(() => profile?.badges || localProfile?.badges || [], [profile, localProfile]);
  
  const nextLevelXp = (effectiveLevel || 1) * 500;
  const progressPercent = Math.min(100, (effectiveXp / nextLevelXp) * 100);

  const isWorkoutSession = pathname?.startsWith('/workout');

  if (authLoading && !localProfile) {
    return (
      <div className="h-[100dvh] w-full flex items-center justify-center bg-background">
        <Dumbbell className="h-12 w-12 text-primary animate-bounce" />
      </div>
    );
  }

  return (
    <div className="flex h-[100dvh] bg-background overflow-hidden font-body">
      {!isWorkoutSession && (
        <aside className="hidden md:flex w-64 flex-col bg-card border-r border-border p-4 shrink-0">
          <div className="flex items-center gap-3 mb-8 px-2">
            <div className="p-2 bg-primary rounded-xl">
              <Dumbbell className="text-primary-foreground h-5 w-5" />
            </div>
            <span className="text-xl font-headline font-bold tracking-tight uppercase">AYURISE</span>
          </div>

          <nav className="flex-1 space-y-1">
            {navItems.map((item) => {
              const isActive = pathname === item.path;
              return (
                <Link
                  key={item.path}
                  href={item.path}
                  prefetch={true}
                  className={cn(
                    "flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-200 group text-sm",
                    isActive 
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <item.icon className={cn("h-4 w-4", isActive ? "" : "group-hover:text-primary")} />
                  <span className="font-bold">{item.name}</span>
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto space-y-4">
            <div className="p-4 bg-secondary/30 rounded-2xl border border-border">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black text-accent uppercase tracking-wider">Rank {effectiveLevel}</span>
                <span className="text-[10px] text-muted-foreground">{effectiveXp} / {nextLevelXp} XP</span>
              </div>
              <Progress value={progressPercent} className="h-1" />
            </div>
            
            <Button 
              variant="ghost" 
              className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10 text-xs h-9 font-bold"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 mr-3" />
              Terminate Session
            </Button>
          </div>
        </aside>
      )}

      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative h-full">
        <header className="h-16 border-b border-border flex items-center justify-between px-4 md:px-8 shrink-0 bg-background/50 backdrop-blur-md z-10">
          <div className="md:hidden flex items-center gap-2">
             <Dumbbell className="text-primary h-5 w-5" />
             <span className="font-headline font-bold text-sm tracking-tighter uppercase">AYURISE</span>
          </div>
          <div className="hidden md:block">
            <h1 className="font-headline text-sm font-black uppercase tracking-widest text-primary">
              Command Center
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden xs:flex items-center gap-2 px-3 py-1 bg-secondary rounded-full border border-border h-8">
              <Flame className="h-3.5 w-3.5 text-orange-500 fill-orange-500" />
              <span className="text-[10px] font-black uppercase">{effectiveStreak}D Streak</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="h-10 w-10 rounded-full bg-primary/20 border border-primary/50 flex items-center justify-center overflow-hidden transition-all hover:ring-4 hover:ring-primary/10">
                  {user?.photoURL ? (
                    <img src={user.photoURL} alt="Profile" className="h-full w-full object-cover" />
                  ) : (
                    <User className="h-5 w-5 text-primary" />
                  )}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-card border-border shadow-2xl">
                <DropdownMenuLabel className="font-headline font-black text-[10px] uppercase tracking-widest text-muted-foreground">Athlete Identity</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="px-2 py-3">
                  <p className="text-sm font-black uppercase truncate">{effectiveName}</p>
                  <p className="text-[8px] font-black uppercase text-primary tracking-widest mt-0.5">Lvl {effectiveLevel} Mastery</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-[10px] font-black uppercase gap-2 cursor-pointer tracking-widest"
                  onSelect={(e) => {
                    e.preventDefault();
                    setIsProfileModalOpen(true);
                  }}
                >
                  <Shield className="h-3.5 w-3.5 text-primary" />
                  Athlete Dossier
                </DropdownMenuItem>
                <DropdownMenuItem className="text-[10px] font-black uppercase gap-2 cursor-pointer tracking-widest" asChild>
                   <Link href="/profile"><User className="h-3.5 w-3.5" /> Full Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-[10px] font-black uppercase gap-2 cursor-pointer text-destructive focus:text-destructive tracking-widest"
                  onClick={handleLogout}
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Terminate
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto p-3 md:p-8 scroll-smooth pb-24 md:pb-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </section>

        {!isWorkoutSession && (
          <nav className="md:hidden h-20 bg-card border-t border-border flex items-center justify-around px-2 shrink-0 z-20 shadow-[0_-8px_30px_rgb(0,0,0,0.12)]">
            {navItems.map((item) => {
              const isActive = pathname === item.path;
              return (
                <Link
                  key={item.path}
                  href={item.path}
                  prefetch={true}
                  className={cn(
                    "flex flex-col items-center justify-center gap-1.5 transition-all duration-200 w-full h-full",
                    isActive ? "text-primary" : "text-muted-foreground opacity-60"
                  )}
                >
                  <item.icon className={cn("h-5 w-5", isActive && "drop-shadow-[0_0_8px_rgba(59,130,246,0.5)]")} />
                  <span className="text-[8px] font-black uppercase tracking-tighter">{item.name}</span>
                </Link>
              );
            })}
          </nav>
        )}
      </main>

      <Dialog open={isProfileModalOpen} onOpenChange={setIsProfileModalOpen}>
        <DialogContent className="sm:max-w-lg bg-card border-border shadow-2xl overflow-y-auto max-h-[90vh] p-0 rounded-3xl">
          <div className="relative h-40 bg-primary flex items-end justify-center pb-0">
             <div className="absolute top-0 right-0 p-4 opacity-10">
                <Trophy className="h-32 w-32 text-white" />
             </div>
             <div className="relative -mb-12 h-24 w-24 rounded-3xl bg-background border-4 border-card flex items-center justify-center shadow-2xl">
                <User className="h-12 w-12 text-primary" />
             </div>
          </div>
          
          <div className="pt-16 pb-10 px-8 text-center space-y-8">
            <DialogHeader className="space-y-1">
              <DialogTitle className="text-2xl font-headline font-black uppercase tracking-tighter text-center">
                {effectiveName}
              </DialogTitle>
              <DialogDescription className="text-[10px] text-muted-foreground uppercase font-black tracking-widest text-center opacity-60">
                System ID: {user?.uid.slice(0, 8) || "ATHLETE_001"}
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-2 gap-4">
               <div className="bg-secondary/30 border border-border rounded-2xl p-4 flex flex-col items-center gap-1 transition-colors hover:bg-secondary/50">
                  <Shield className="h-5 w-5 text-primary" />
                  <span className="text-[8px] font-black uppercase text-muted-foreground tracking-widest mt-1">Mastery Level</span>
                  <span className="text-2xl font-black font-headline">{effectiveLevel}</span>
               </div>
               <div className="bg-secondary/30 border border-border rounded-2xl p-4 flex flex-col items-center gap-1 transition-colors hover:bg-secondary/50">
                  <Zap className="h-5 w-5 text-accent" />
                  <span className="text-[8px] font-black uppercase text-muted-foreground tracking-widest mt-1">Total XP</span>
                  <span className="text-2xl font-black font-headline">{effectiveXp}</span>
               </div>
            </div>

            <div className="space-y-3">
               <div className="flex items-center justify-between px-1">
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Mastery Track</span>
                  <span className="text-[10px] font-bold text-muted-foreground">{effectiveXp} / {nextLevelXp} XP</span>
               </div>
               <div className="h-3 bg-secondary rounded-full overflow-hidden border border-border">
                  <div 
                    className="h-full bg-primary transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(59,130,246,0.3)]" 
                    style={{ width: `${progressPercent}%` }} 
                  />
               </div>
            </div>

            <div className="space-y-4">
               <div className="flex items-center gap-2 px-1">
                  <Award className="h-4 w-4 text-primary" />
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em]">Rank Badges</h4>
               </div>
               <div className="grid grid-cols-2 gap-3">
                  {BADGES.map((badge) => {
                    const isEarned = earnedBadges.includes(badge.id);
                    return (
                      <div 
                        key={badge.id} 
                        className={cn(
                          "p-4 rounded-2xl border flex flex-col items-center text-center gap-1.5 transition-all",
                          isEarned 
                            ? "bg-accent/10 border-accent/30 text-accent shadow-lg shadow-accent/5" 
                            : "bg-secondary/20 border-border opacity-40 grayscale"
                        )}
                      >
                         <div className={cn("p-2 rounded-xl", isEarned ? "bg-accent/20" : "bg-muted")}>
                           <Star className={cn("h-5 w-5", isEarned ? "fill-accent" : "text-muted-foreground")} />
                         </div>
                         <p className="text-[9px] font-black uppercase tracking-tighter leading-tight mt-1">{badge.name}</p>
                      </div>
                    );
                  })}
               </div>
            </div>

            <Button 
              className="w-full h-14 rounded-2xl text-[10px] font-black uppercase tracking-widest gap-2 shadow-2xl shadow-primary/10"
              onClick={() => setIsProfileModalOpen(false)}
            >
              Back to training <ChevronRight className="h-3 w-3" />
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
