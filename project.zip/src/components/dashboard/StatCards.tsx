
"use client";

import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Clock, Zap, Target } from "lucide-react";
import { useUser, useDoc } from "@/firebase";

export function StatCards() {
  const { user } = useUser();
  const { data: profile } = useDoc(user ? `users/${user.uid}` : null);
  const [stats, setStats] = useState({
    workouts: 0,
    minutes: 0,
    skills: 0,
    xp: 0
  });

  useEffect(() => {
    // Sync with local storage or firestore
    const localWorkouts = parseInt(localStorage.getItem('ayush_workouts_count') || '0');
    const localXP = parseInt(localStorage.getItem('ayush_xp') || '0');
    
    setStats({
      workouts: profile?.workouts || localWorkouts,
      minutes: (profile?.workouts || localWorkouts) * 15, // Approx 15 mins per workout
      skills: profile?.skills_count || 0,
      xp: profile?.xp || localXP
    });
  }, [profile]);

  const displayStats = [
    { label: "Workouts", value: stats.workouts.toString(), icon: Zap, color: "text-primary", bg: "bg-primary/10" },
    { label: "Active Mins", value: stats.minutes.toString(), icon: Clock, color: "text-accent", bg: "bg-accent/10" },
    { label: "Rank", value: Math.floor(stats.xp / 500 + 1).toString(), icon: Trophy, color: "text-yellow-500", bg: "bg-yellow-500/10" },
    { label: "Total XP", value: stats.xp.toString(), icon: Target, color: "text-green-500", bg: "bg-green-500/10" },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
      {displayStats.map((stat) => (
        <Card key={stat.label} className="bg-card/50 border-border overflow-hidden">
          <CardContent className="p-3 md:p-4 flex items-center gap-2 md:gap-4">
            <div className={`p-2 md:p-3 rounded-xl ${stat.bg} shrink-0`}>
              <stat.icon className={`h-4 w-4 md:h-6 md:w-6 ${stat.color}`} />
            </div>
            <div className="min-w-0">
              <p className="text-[8px] md:text-[10px] font-black uppercase text-muted-foreground tracking-widest truncate">{stat.label}</p>
              <p className="text-lg md:text-xl font-black font-headline">{stat.value}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
