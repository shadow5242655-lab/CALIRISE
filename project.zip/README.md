# AYURISE | Ultimate Bodyweight Mastery

This is a high-performance Next.js application built for calisthenics athletes to track their 30-day mastery journeys.

## Features
- **30-Day Mastery Paths**: Sequentially locked programs from Beginner to Elite, scaling from joint integrity to elite static holds.
- **Identity Forging**: A streamlined local-first profile system. No passwords required—just forge your rank name and start training.
- **The Pavilion (Community)**: Global rankings and challenges (simulated with local sync).
- **The Forge**: Custom routine builder with AI-assisted neural planning.
- **Protein Pipeline**: Nutrition strategies tailored to your current mastery path.

## Deployment

To deploy this app:

1. **GitHub Setup**: 
   ```bash
   git remote add origin https://github.com/shadow5242655-lab/CALIRISE.git
   git push -u origin main
   ```
2. **Import to Vercel**:
   - Go to [vercel.com/new](https://vercel.com/new).
   - Import your repository.
3. **Environment Variables**:
   - The app defaults to **Guest Mode** (Local Storage) automatically. 
   - For Cloud Sync, add your Firebase keys (e.g., `NEXT_PUBLIC_FIREBASE_API_KEY`).

## Tech Stack
- **Framework**: Next.js 15 (App Router)
- **Styling**: Tailwind CSS + ShadCN UI
- **AI**: Genkit + Gemini 1.5 Flash
- **Database**: Firebase (Optional Cloud Sync) / LocalStorage (Default)

## Development

Run the development server:
```bash
npm run dev
```

The app is optimized for high-performance mobile views with `100dvh` viewport handling.
